<#
.SYNOPSIS
    Builds qemu-system-ppc.exe (the ppcosxkvm QEMU fork) on Windows.

.DESCRIPTION
    One command from a fresh Windows 10/11 x64 machine to a working exe:

        powershell -ExecutionPolicy Bypass -File .\build-windows.ps1

    It (1) compiles the GUI (ppcosx-gui.exe), (2) installs and repairs MSYS2 if
    needed, (3) installs the build dependencies, (4) fetches the qemu submodule
    and applies windows\patches\*.patch, (5) builds QEMU, and (6) collects the
    exe and its DLLs in .\win-qemu\.

    Everything it prints is also written to build-windows.log next to this
    script, so there is always a log to look at, even if the window closes.

    Only want the window? Compile it in a few seconds, no MSYS2 needed:

        powershell -ExecutionPolicy Bypass -File .\build-windows.ps1 -GuiOnly

.PARAMETER Msys2Dir
    Where MSYS2 lives (installed there if missing). Must end in \msys64.
.PARAMETER Jobs
    Parallel compile jobs (default: number of CPU threads).
.PARAMETER Clean
    Delete win-build\ and win-qemu\ first and rebuild from scratch.
.PARAMETER SkipMsys2Update
    Do not run "pacman -Syuu" (faster re-runs).
.PARAMETER ResetMsys2
    Delete the MSYS2 folder and install it again. Use this if MSYS2 was left
    half-installed (for example the window was closed during the first run).
.PARAMETER GuiOnly
    Just compile ppcosx-gui.exe (needs nothing but Windows) and stop.
.PARAMETER NoGui
    Skip compiling the GUI (the GUI passes this, because it is running).
.PARAMETER NoPause
    Never wait for Enter at the end.
.PARAMETER DryRun
    Print the plan and write the build script, but change nothing.
#>
[CmdletBinding()]
param(
    [string]$Msys2Dir = 'C:\msys64',
    [int]$Jobs = 0,
    [switch]$Clean,
    [switch]$SkipMsys2Update,
    [switch]$ResetMsys2,
    [switch]$GuiOnly,
    [switch]$NoGui,
    [switch]$NoPause,
    [switch]$DryRun
)

$ErrorActionPreference = 'Stop'
Set-StrictMode -Version 2.0
$ProgressPreference = 'SilentlyContinue'     # Windows PowerShell 5.1 downloads crawl with the progress bar on

$ScriptVersion = 'v8'
$Repo = $PSScriptRoot
$BuildDir = Join-Path $Repo 'win-build'
$OutDir = Join-Path $Repo 'win-qemu'
$LogFile = Join-Path $Repo 'build-windows.log'
try { Set-Content -Path $LogFile -Value ("ppcosxkvm Windows build script $ScriptVersion, " + (Get-Date -Format 'yyyy-MM-dd HH:mm:ss')) -Encoding ASCII } catch {}
Write-Host "build-windows.ps1 $ScriptVersion" -ForegroundColor DarkGray

# ---------------------------------------------------------------- output + log ---
function Log([string]$m) { try { [System.IO.File]::AppendAllText($LogFile, $m + "`r`n") } catch {} }
function Say([string]$m)  { Write-Host ''; Write-Host "==> $m" -ForegroundColor Cyan; Log ''; Log "==> $m" }
function Ok([string]$m)   { Write-Host "  OK $m" -ForegroundColor Green; Log "  OK $m" }
function Warn([string]$m) { Write-Host "  !! $m" -ForegroundColor Yellow; Log "  !! $m" }
function Info([string]$m) { Write-Host "  $m"; Log "  $m" }

function Started-From-Explorer {   # double-click / "Run with PowerShell": the window dies with the script
    try {
        $me = Get-CimInstance Win32_Process -Filter "ProcessId=$PID" -ErrorAction Stop
        $par = Get-CimInstance Win32_Process -Filter "ProcessId=$($me.ParentProcessId)" -ErrorAction Stop
        return ($par.Name -eq 'explorer.exe')
    } catch { return $false }
}

function Finish([int]$code) {
    if ($code -ne 0) {
        Write-Host ''
        Write-Host "The full log is in: $LogFile" -ForegroundColor Yellow
    }
    if (-not $NoPause -and (Started-From-Explorer)) { [void](Read-Host 'Press Enter to close this window') }
    exit $code
}

function Die([string]$m) {
    Write-Host "error: $m" -ForegroundColor Red; Log "error: $m"
    Finish 1
}

function Quote-Arg([string]$a) {
    if ($a.Length -gt 0 -and $a -notmatch '[\s"]') { return $a }
    $sb = New-Object System.Text.StringBuilder
    [void]$sb.Append('"')
    $bs = 0
    foreach ($c in $a.ToCharArray()) {
        if ($c -eq [char]'\') { $bs++ }
        elseif ($c -eq [char]'"') { [void]$sb.Append('\' * ($bs * 2 + 1)); [void]$sb.Append('"'); $bs = 0 }
        else { if ($bs -gt 0) { [void]$sb.Append('\' * $bs); $bs = 0 }; [void]$sb.Append($c) }
    }
    if ($bs -gt 0) { [void]$sb.Append('\' * ($bs * 2)) }
    [void]$sb.Append('"')
    $sb.ToString()
}

# ---------------------------------------------------------------- the GUI ---
# One C# file, built with the compiler that ships with Windows (.NET Framework 4).
function Build-Gui {
    Say 'Building ppcosx-gui.exe'
    $src = Join-Path $Repo 'gui\PpcOsxGui.cs'
    $out = Join-Path $Repo 'ppcosx-gui.exe'
    if (-not (Test-Path $src)) { Warn 'gui\PpcOsxGui.cs is missing; skipping the GUI.'; return }
    $csc = @("$env:windir\Microsoft.NET\Framework64\v4.0.30319\csc.exe",
             "$env:windir\Microsoft.NET\Framework\v4.0.30319\csc.exe") | Where-Object { Test-Path $_ } | Select-Object -First 1
    if (-not $csc) {
        Warn 'The .NET Framework 4 compiler (csc.exe) was not found, so the GUI was not rebuilt.'
        return
    }
    $tmp = Join-Path $Repo 'ppcosx-gui.new.exe'
    $text = & $csc /nologo /target:winexe /platform:x64 /optimize+ "/out:$tmp" /r:System.Windows.Forms.dll /r:System.Drawing.dll /r:System.Web.Extensions.dll $src 2>&1 | Out-String
    if ($LASTEXITCODE -ne 0) {
        Log $text
        Warn "Compiling the GUI failed; the existing ppcosx-gui.exe (if any) is kept.`n$text"
        return
    }
    try { Move-Item -Force $tmp $out; Ok $out }
    catch { Remove-Item -Force -ErrorAction SilentlyContinue $tmp; Warn 'ppcosx-gui.exe is running right now, so it was not replaced (that is fine).' }
}

if ($GuiOnly) {
    if ($env:OS -ne 'Windows_NT') { Die 'This script is for Windows.' }
    Build-Gui
    Write-Host ''
    Write-Host '  Start it:  .\ppcosx-gui.exe'
    Finish 0
}

# ---------------------------------------------------------------- MSYS2 helpers ---
$Bash = [System.IO.Path]::Combine($Msys2Dir, 'usr\bin\bash.exe')

# Run bash in MSYS2, show its output live and log it. Returns the exit code.
function Invoke-Msys([string[]]$BashArgs, [switch]$AllowFail, [switch]$Quiet) {
    $psi = New-Object System.Diagnostics.ProcessStartInfo
    $psi.FileName = $Bash
    $psi.Arguments = (($BashArgs | ForEach-Object { Quote-Arg $_ }) -join ' ')
    $psi.UseShellExecute = $false
    $psi.RedirectStandardOutput = $true
    $psi.RedirectStandardError = $true
    $psi.StandardOutputEncoding = [System.Text.Encoding]::UTF8
    $psi.StandardErrorEncoding = [System.Text.Encoding]::UTF8
    $psi.CreateNoWindow = $true
    $psi.EnvironmentVariables['MSYSTEM'] = 'UCRT64'
    $psi.EnvironmentVariables['CHERE_INVOKING'] = '1'
    $p = [System.Diagnostics.Process]::Start($psi)
    $outT = $p.StandardOutput.ReadLineAsync()
    $errT = $p.StandardError.ReadLineAsync()
    $outDone = $false; $errDone = $false
    while (-not ($outDone -and $errDone)) {
        $moved = $false
        if (-not $outDone -and $outT.IsCompleted) {
            $l = $outT.Result
            if ($null -eq $l) { $outDone = $true } else { if (-not $Quiet) { Write-Host $l }; Log $l; $outT = $p.StandardOutput.ReadLineAsync() }
            $moved = $true
        }
        if (-not $errDone -and $errT.IsCompleted) {
            $l = $errT.Result
            if ($null -eq $l) { $errDone = $true } else { if (-not $Quiet) { Write-Host $l }; Log $l; $errT = $p.StandardError.ReadLineAsync() }
            $moved = $true
        }
        if (-not $moved) { Start-Sleep -Milliseconds 40 }
    }
    $p.WaitForExit()
    $code = $p.ExitCode
    if ($code -ne 0 -and -not $AllowFail) { Die "An MSYS2 command failed with exit code $code (details above and in the log)." }
    return $code
}

# MSYS2's pacman needs a certificate bundle to talk HTTPS. If MSYS2's first-run setup was
# interrupted it is missing, and every download then fails with "error adding trust anchors".
function Test-Certs { return ((Invoke-Msys @('-lc', 'n=$(grep -c "BEGIN CERTIFICATE" /usr/ssl/certs/ca-bundle.crt 2>/dev/null); [ "${n:-0}" -ge 20 ]') -Quiet -AllowFail) -eq 0) }

function Export-WindowsRootCerts([string]$dest) {
    $sb = New-Object System.Text.StringBuilder
    $seen = @{}
    foreach ($loc in 'LocalMachine', 'CurrentUser') {
        $store = New-Object System.Security.Cryptography.X509Certificates.X509Store('Root', $loc)
        $store.Open('ReadOnly')
        foreach ($c in $store.Certificates) {
            if ($seen.ContainsKey($c.Thumbprint)) { continue }
            $seen[$c.Thumbprint] = 1
            [void]$sb.Append("-----BEGIN CERTIFICATE-----`n")
            $b64 = [Convert]::ToBase64String($c.RawData)
            for ($i = 0; $i -lt $b64.Length; $i += 64) { [void]$sb.Append($b64.Substring($i, [Math]::Min(64, $b64.Length - $i)) + "`n") }
            [void]$sb.Append("-----END CERTIFICATE-----`n")
        }
        $store.Close()
    }
    New-Item -ItemType Directory -Force -Path (Split-Path $dest -Parent) | Out-Null
    Remove-Item -Force -ErrorAction SilentlyContinue $dest        # may be an MSYS symlink stub
    [System.IO.File]::WriteAllText($dest, $sb.ToString(), (New-Object System.Text.UTF8Encoding($false)))
    return $seen.Count
}

function Ensure-Msys2-Ready {
    Info 'First start: this sets up the package keys and certificates (up to a couple of minutes)...'
    [void](Invoke-Msys @('-lc', 'echo MSYS2 shell works') -AllowFail:$false)

    if (-not (Test-Certs)) {
        Warn 'MSYS2 has no certificate bundle yet (its first-run setup did not finish). Repairing...'
        [void](Invoke-Msys @('-lc', 'update-ca-trust') -AllowFail -Quiet)
        if (-not (Test-Certs)) {
            try { [void](Invoke-WebRequest -Uri 'https://mirror.msys2.org/' -UseBasicParsing -Method Head -TimeoutSec 30) } catch {}  # lets Windows fetch any missing roots
            $dest = [System.IO.Path]::Combine($Msys2Dir, 'usr\ssl\certs\ca-bundle.crt')
            $n = Export-WindowsRootCerts $dest
            Info "Wrote $n trusted root certificates from Windows to $dest"
            if (-not (Test-Certs)) { Die "Could not repair MSYS2's certificate bundle. Try:  .\build-windows.ps1 -ResetMsys2" }
        }
        Ok 'certificate bundle repaired'
    } else { Ok 'certificate bundle present' }

    $rc = Invoke-Msys @('-lc', 'test -f /etc/pacman.d/gnupg/trustdb.gpg') -Quiet -AllowFail
    if ($rc -ne 0) {
        Warn 'Package signing keys are not set up yet. Initialising them (this can take a minute)...'
        [void](Invoke-Msys @('-lc', 'pacman-key --init && pacman-key --populate msys2') -AllowFail)
    }
}

function Install-Msys2 {
    $parent = Split-Path $Msys2Dir -Parent
    $inst = Join-Path $env:TEMP 'msys2-x86_64-latest.sfx.exe'
    Info 'Downloading the MSYS2 installer (about 100 MB)...'
    [Net.ServicePointManager]::SecurityProtocol = [Net.ServicePointManager]::SecurityProtocol -bor [Net.SecurityProtocolType]::Tls12
    Invoke-WebRequest -Uri 'https://repo.msys2.org/distrib/msys2-x86_64-latest.sfx.exe' -OutFile $inst -UseBasicParsing
    Info "Extracting to $Msys2Dir (a minute or two; the window may look idle)..."
    & $inst -y "-o$parent" | Out-Null
    if (-not (Test-Path $Bash)) { Die "MSYS2 did not install to $Msys2Dir." }
}

# ---------------------------------------------------------------- main ---
try {

Say 'Checking this machine'
if (-not $DryRun) {
    if ($env:OS -ne 'Windows_NT') { Die 'This script is for Windows. On macOS/Linux use ./ppcosx setup.' }
    if (-not [Environment]::Is64BitOperatingSystem) { Die '64-bit Windows is required.' }
}
if ($Repo -match '\s') {
    Die "The repository path contains spaces ($Repo). Move it to something like C:\ppcosxkvm and try again."
}
if ($Repo.Length -gt 60) { Warn 'The repository path is long; if the build fails with path errors, move it closer to C:\.' }
if (-not (Test-Path (Join-Path $Repo '.git')) -and -not (Test-Path (Join-Path $Repo 'qemu\configure'))) {
    Die ('This is not a git checkout, so the qemu submodule cannot be fetched.' +
         ' Use:  git clone -c core.autocrlf=false https://github.com/linuxkid473/ppcosxkvm.git')
}
if ((Split-Path $Msys2Dir -Leaf) -ne 'msys64') { Die '-Msys2Dir must end in \msys64 (the MSYS2 installer always creates that folder).' }
Ok "repository: $Repo"

if (-not $NoGui -and -not $DryRun) { Build-Gui }

# The build script that runs inside MSYS2. Single-quoted here-string: PowerShell leaves the $ signs alone.
$BashScript = @'
#!/bin/bash
set -euo pipefail
export MSYSTEM=UCRT64

REPO=$(cygpath -u "$PPC_REPO")
OUT="$REPO/win-qemu"
BUILD="$REPO/win-build"
cd "$REPO"
say() { printf '\n==> %s\n' "$*"; }
P=mingw-w64-ucrt-x86_64

# --- 1. packages -------------------------------------------------------
say "Installing build dependencies (pacman)"
REQUIRED="bison diffutils flex git grep make sed
  $P-binutils $P-gcc $P-glib2 $P-ninja $P-pixman $P-pkgconf $P-python $P-python-pip
  $P-zstd $P-libslirp $P-SDL2 $P-shaderc $P-spirv-cross $P-vulkan-headers $P-vulkan-loader"
bad=0
for p in $REQUIRED; do
    pacman -Si "$p" >/dev/null 2>&1 || { echo "package not found in MSYS2: $p"; bad=1; }
done
[ "$bad" = 0 ] || { echo "error: a required MSYS2 package is missing (see above); try without -SkipMsys2Update"; exit 1; }
pacman -S --needed --noconfirm $REQUIRED
# Optional: libfdt. Without it QEMU downloads and builds its own copy.
pacman -Si $P-dtc >/dev/null 2>&1 && pacman -S --needed --noconfirm $P-dtc || echo "(no dtc package; QEMU will build libfdt itself)"

# The Radeon's 3D engine needs these three; fail early and clearly.
for m in vulkan shaderc spirv-cross-c-shared; do
    pkg-config --exists "$m" || { echo "error: pkg-config cannot find '$m' (needed for the Vulkan 3D renderer)"; exit 1; }
done
echo "3D dependencies found: vulkan $(pkg-config --modversion vulkan), shaderc $(pkg-config --modversion shaderc)"

# --- 2. QEMU source ----------------------------------------------------
say "Fetching the QEMU source"
WANT=$(git rev-parse HEAD:qemu 2>/dev/null || true)
HAVE=$(git -C qemu rev-parse HEAD 2>/dev/null || true)
if [ ! -f qemu/configure ] || { [ -n "$WANT" ] && [ "$WANT" != "$HAVE" ]; }; then
    # Undo our patch first so the checkout of a new commit cannot conflict.
    for p in "$REPO"/windows/patches/*.patch; do
        [ -f qemu/configure ] && git -C qemu apply --reverse --ignore-whitespace "$p" >/dev/null 2>&1 || true
    done
    # LF line endings: QEMU's configure is a shell script and breaks with CRLF.
    git -c core.autocrlf=false -c core.eol=lf submodule update --init --depth 1 qemu
fi
[ -f qemu/configure ] || { echo "error: qemu/ is empty; run: git submodule update --init --depth 1 qemu"; exit 1; }
if grep -q $'\r' qemu/configure; then
    echo "qemu/ was checked out with CRLF line endings; converting to LF"
    git -C qemu config core.autocrlf false
    git -C qemu config core.eol lf
    git -C qemu rm --cached -r -q .
    git -C qemu reset --hard -q
fi
echo "qemu @ $(git -C qemu rev-parse --short HEAD)"

# --- 3. Windows patches --------------------------------------------------
say "Applying Windows patches"
for p in "$REPO"/windows/patches/*.patch; do
    [ -f "$p" ] || continue
    if git -C qemu apply --reverse --check --ignore-whitespace "$p" >/dev/null 2>&1; then
        # exactly this patch is already in place: leave the files alone (touching them would make
        # the build system regenerate itself for nothing)
        echo "already applied: $(basename "$p")"
        continue
    fi
    # Otherwise start from pristine copies of the files this patch touches. That lets an updated
    # patch replace an older version of itself that was applied by an earlier run.
    files=$(git -C qemu apply --numstat "$p" | cut -f3)
    # shellcheck disable=SC2086
    git -C qemu checkout -- $files
    if git -C qemu apply --ignore-whitespace "$p"; then
        echo "applied: $(basename "$p") ($(echo "$files" | wc -w) files)"
    else
        echo "error: $(basename "$p") does not apply to qemu @ $(git -C qemu rev-parse --short HEAD)."
        echo "The patch was made for the commit the repo pinned when the Windows port was written."
        echo "See docs/WINDOWS.md ('If the patch no longer applies')."
        exit 1
    fi
done

# --- 4. configure --------------------------------------------------------
say "Configuring QEMU"
if [ "${PPC_CLEAN:-0}" = 1 ]; then rm -rf "$BUILD" "$OUT"; fi
mkdir -p "$BUILD"
cd "$BUILD"
if [ ! -f build.ninja ]; then
    # --disable-gtk: the SDL window needs no extra GTK runtime files.
    # -Dhardening=false: this fork's speed option (see its meson_options.txt).
    ../qemu/configure --prefix="$(cygpath -m "$OUT")" --target-list=ppc-softmmu \
        --disable-docs --disable-werror --disable-guest-agent \
        --enable-sdl --disable-gtk --enable-slirp \
        -Dhardening=false -Doptimization=2 \
        > ppcosx-configure.log 2>&1 \
        || { tail -40 ppcosx-configure.log; echo "error: configure failed; full log: win-build/ppcosx-configure.log"; exit 1; }
fi
echo "configured"

# --- 4b. make the build settings regeneration-proof ---------------------
MESON=$(sed -n 's/^MESON=//p' config-host.mak)
[ -n "$MESON" ] || { echo "error: cannot find meson in config-host.mak"; exit 1; }
# configure writes "werror = true" into the machine file for git checkouts, and Meson lets a
# machine-file value override the command line whenever it regenerates the build files (any
# MSYS2 update or edited file does that). That would switch -Werror back on and break the build
# with a newer GCC. Remove it, then set the options explicitly if they are not what we want.
sed -i '/^werror = true/d' config-meson.cross
norm() { printf '%s' "$1" | tr '\\' '/' | tr 'A-Z' 'a-z'; }
WANT_PREFIX=$(cygpath -m "$OUT")
cur=$("$MESON" configure . 2>/dev/null || true)
need=()
[ "$(echo "$cur" | awk '$1=="werror"{print $2; exit}')" = false ] || need+=(-Dwerror=false)
[ "$(norm "$(echo "$cur" | awk '$1=="prefix"{print $2; exit}')")" = "$(norm "$WANT_PREFIX")" ] || need+=("-Dprefix=$WANT_PREFIX")
if [ "${#need[@]}" -gt 0 ]; then
    echo "setting build options: ${need[*]}"
    "$MESON" configure . "${need[@]}" > ppcosx-meson-configure.log 2>&1 \
        || { tail -20 ppcosx-meson-configure.log; echo "error: could not set build options; log: win-build/ppcosx-meson-configure.log"; exit 1; }
fi

# --- 5. build ------------------------------------------------------------
say "Building QEMU (about 10-30 minutes the first time)"
JOBS=${PPC_JOBS:-0}
[ "$JOBS" -gt 0 ] || JOBS=$(nproc)
# QEMU builds its own unit-test programs by default too, and some of them do not link on
# Windows (an upstream bug, e.g. test-vmstate: undefined reference to qemu_ftruncate64).
# We never need a test program, so keep going past failures (-k 0) and only stop if
# something outside tests/ failed.
set +e
ninja -k 0 -j"$JOBS" 2>&1 | tee ppcosx-build.log | awk '/^\[[0-9]+\/[0-9]+\] /{n++; if (n%40==0) {print; fflush()}; next} {print; fflush()}'
rc=${PIPESTATUS[0]}
set -e
if [ "$rc" != 0 ]; then
    bad=$(grep -E '^FAILED:' ppcosx-build.log | sed -E 's/^FAILED: *(\[code=[0-9]+\] *)?//; s/ +$//' | grep -vE '^tests/' || true)
    if [ -n "$bad" ]; then
        echo "error: these targets failed to build:"
        echo "$bad"
        grep -E 'error|undefined reference' ppcosx-build.log | head -20 || true
        echo "error: build failed; full log: win-build/ppcosx-build.log"
        exit 1
    fi
    echo "note: ignoring $(grep -cE '^FAILED:' ppcosx-build.log) QEMU test program(s) that do not build on Windows (not needed)"
fi

# --- 6. install + DLLs ---------------------------------------------------
say "Collecting qemu-system-ppc.exe and its DLLs in win-qemu/"
# "ninja install" would rebuild everything first (including the broken test). Install what is built.
MESON=$(sed -n 's/^MESON=//p' config-host.mak)
[ -n "$MESON" ] || { echo "error: cannot find meson in config-host.mak"; exit 1; }
"$MESON" install --no-rebuild > ppcosx-install.log 2>&1 || { tail -20 ppcosx-install.log; echo "error: install failed; full log: win-build/ppcosx-install.log"; exit 1; }
for exe in "$OUT/qemu-system-ppc.exe" "$OUT/qemu-img.exe"; do
    [ -f "$exe" ] || { echo "error: $exe was not produced"; exit 1; }
done
# Copy every MSYS2 DLL the programs import, then the DLLs those import, and so on.
# (Reads the imports with objdump; Windows' own DLLs are not in /ucrt64/bin and are skipped.)
copy_dlls() {
    local queue=("$@") seen=" " f d
    while [ "${#queue[@]}" -gt 0 ]; do
        f=${queue[0]}
        queue=("${queue[@]:1}")
        for d in $(objdump -p "$f" 2>/dev/null | awk '/DLL Name:/ {print $3}'); do
            case "$seen" in *" $d "*) continue ;; esac
            seen="$seen$d "
            if [ -f "/ucrt64/bin/$d" ]; then
                cp -u "/ucrt64/bin/$d" "$OUT/"
                queue+=("/ucrt64/bin/$d")
            fi
        done
    done
}
copy_dlls "$OUT"/*.exe
echo "copied $(find "$OUT" -maxdepth 1 -name '*.dll' | wc -l) DLLs next to the programs"
cp -u "$REPO/qemu/COPYING" "$OUT/COPYING"

say "Checking the result"
# Output goes into variables first: piping into "grep -q" or "head" closes the pipe early,
# which makes the program exit non-zero and (with pipefail) would be reported as a failure.
ver=$("$OUT/qemu-system-ppc.exe" --version 2>&1 || true)
echo "${ver%%$'\n'*}"
devs=$("$OUT/qemu-system-ppc.exe" -device help 2>&1 || true)
case "$devs" in
    *ati-radeon-9700*) echo "ati-radeon-9700 device present" ;;
    *) echo "error: this QEMU has no ati-radeon-9700 device (output was:)"; echo "$devs" | head -5; exit 1 ;;
esac
props=$("$OUT/qemu-system-ppc.exe" -device ati-radeon-9700,help 2>&1 || true)
case "$props" in
    *renderer*) echo "renderer option present (vulkan)" ;;
    *) echo "warning: the Radeon device has no renderer option" ;;
esac
echo BUILD_OK
'@

# written with LF endings and no BOM: a CRLF in a bash script breaks it
New-Item -ItemType Directory -Force -Path $BuildDir | Out-Null
$BashFile = Join-Path $BuildDir 'ppcosx-build.sh'
$utf8 = New-Object System.Text.UTF8Encoding($false)
[System.IO.File]::WriteAllText($BashFile, ($BashScript -replace "`r`n", "`n"), $utf8)

if ($DryRun) {
    Say 'Dry run: nothing was installed or built'
    Ok "build script written to $BashFile"
    Ok "MSYS2 would be used from $Msys2Dir"
    Finish 0
}

Say 'MSYS2'
if ($ResetMsys2 -and (Test-Path $Msys2Dir)) {
    Warn "-ResetMsys2: deleting $Msys2Dir and installing it again"
    Get-Process | Where-Object { $_.Path -and $_.Path.StartsWith($Msys2Dir, [StringComparison]::OrdinalIgnoreCase) } | Stop-Process -Force -ErrorAction SilentlyContinue
    Remove-Item -Recurse -Force $Msys2Dir
}
if (-not (Test-Path $Bash)) { Install-Msys2 }
Ok "MSYS2 at $Msys2Dir"
Ensure-Msys2-Ready

if (-not $SkipMsys2Update) {
    Info 'Updating MSYS2 (pass 1 of 2; the core update may stop early, that is normal)...'
    [void](Invoke-Msys @('-lc', 'pacman --noconfirm -Syuu') -AllowFail)
    Info 'Updating MSYS2 (pass 2 of 2)...'
    [void](Invoke-Msys @('-lc', 'pacman --noconfirm -Syuu'))
} else {
    [void](Invoke-Msys @('-lc', 'pacman --noconfirm -Sy'))
}

# ---------------------------------------------------------------- build ---
$env:PPC_REPO = $Repo.Replace('\', '/')
$env:PPC_JOBS = [string]$Jobs
$env:PPC_CLEAN = $(if ($Clean) { '1' } else { '0' })
[void](Invoke-Msys @('-l', $BashFile.Replace('\', '/')))

$exe = Join-Path $OutDir 'qemu-system-ppc.exe'
if (-not (Test-Path $exe)) { Die 'The build finished but qemu-system-ppc.exe is missing.' }
Say 'Done'
Ok $exe
Write-Host ''
Write-Host '  Next:  .\ppcosx-gui.exe              (the window)'
Write-Host '    or:  .\ppcosx.ps1 doctor           (command line)'
Write-Host '         .\ppcosx.ps1 install C:\path\to\MacOSX-Tiger.iso'
Finish 0

} catch {
    # anything unexpected: say what and where, instead of the window just vanishing
    Write-Host "error: $($_.Exception.Message)" -ForegroundColor Red
    Log "error: $($_.Exception.Message)"
    Log ($_.ScriptStackTrace)
    Finish 1
}
