# ppcosxkvm on Windows

Run PowerPC Mac OS X (Tiger) on Windows 10/11 x64, with the emulated ATI Radeon
9700 PRO and its 3D engine translated to **Vulkan**.

> **Status.** This port was assembled and checked without access to a Windows
> machine. What was verified: both PowerShell scripts parse and run under
> PowerShell 7; the Windows launcher produces the *same QEMU command line* as
> the bash launcher for every scenario tried; the QEMU patch applies cleanly
> and the patched tree configures and compiles on Linux; the MSYS2 build steps
> pass `bash -n` and `shellcheck`; the GUI compiles as C# 5 and was run and
> clicked through (start, install, snapshots) under Mono's WinForms against the
> real launcher. What has **not** been run: the actual MSYS2 compile of QEMU,
> the GUI on real Windows, and the Vulkan renderer on a Windows GPU driver.
> Expect to possibly hit a snag on first build; the Troubleshooting section
> lists the likely ones.

## What gets hardware acceleration

| Guest | Card | 3D on Windows |
|---|---|---|
| Mac OS X 10.4 Tiger, 10.5 Leopard (the default) | Radeon 9700 PRO (R300) | **Your GPU, through Vulkan** (Quartz Extreme, Core Image, OpenGL) |
| any | plain VGA (`--vga`) | none (safe mode) |
| Mac OS X 10.2 Jaguar (`--jaguar`) | Radeon 9000 (R200) | software renderer: slow and incomplete |

Jaguar is the only gap. This project implements the Radeon 9000's 3D engine
only for Apple's Metal; the Vulkan renderer is written for the R300 and the
device refuses `renderer=vulkan` on a Radeon 9000. Giving Jaguar hardware 3D on
Windows means writing a Vulkan backend for the R200 (about 700 R200-specific
code paths live in the Metal file), which is a project-sized change to the QEMU
fork itself, not something a launcher port can add.

## Quick start

You need: Windows 10/11 (64-bit), a GPU driver with Vulkan 1.1+ (NVIDIA, AMD
or Intel; any driver from the last several years), about 8 GB free disk,
`git`, and a legally obtained Mac OS X Tiger install DVD image.

```powershell
# 1. Clone WITHOUT line-ending conversion, somewhere short with no spaces
git clone -c core.autocrlf=false https://github.com/linuxkid473/ppcosxkvm.git C:\ppcosxkvm
cd C:\ppcosxkvm

# 2. Build qemu-system-ppc.exe (installs MSYS2 if needed; 20-40 min the first time)
powershell -ExecutionPolicy Bypass -File .\build-windows.ps1

# 3. Open the GUI (built by step 2), or use the command line:
.\ppcosx-gui.exe

.\ppcosx.cmd doctor
.\ppcosx.cmd install C:\path\to\MacOSX-Tiger.iso
.\ppcosx.cmd
```

## The GUI (`ppcosx-gui.exe`)

A desktop front-end for everything below: a list of virtual machines, a
settings panel per VM, big Start / Force-stop buttons, and a live log of what
QEMU and the launcher are saying.

* **Sidebar:** your VMs; *Install Mac OS X...* (a wizard that creates the
  disk and runs the installer), *Import existing disk...* (qcow2, vmdk, vdi,
  vhd, img or a UTM bundle), *Check setup* (runs `ppcosx doctor`, including a
  Vulkan self-test) and *Build / Update QEMU* (runs `build-windows.ps1` with
  live output).
* **Hardware tab:** graphics mode (Radeon 9700 / plain VGA / Jaguar), video
  memory, screen size, RAM, Mac model, CPU speed shown to Mac OS X, which GPU
  to use if you have two, window type, sound.
* **Storage tab:** disk image (browse or create), disc in the drive, Radeon
  ROM, snapshot mode, and disk snapshots (save / restore / delete).
* **Network & advanced tab:** verbose boot, SSH port forward, QEMU monitor,
  GPU trace, extra QEMU arguments.
* **Below the tabs:** the log, and the exact `ppcosx` command line the current
  settings produce (with a *Copy command* button), so anything you set up in
  the window can be repeated or shared as a one-liner.

VM settings are saved in `vm\profiles.json`. The window is only a front-end: it
runs `ppcosx.ps1`, so the GUI and the command line behave identically.

`ppcosx-gui.exe` is built from `gui\PpcOsxGui.cs` by `build-windows.ps1` using
the .NET Framework compiler that ships with Windows. To rebuild only the
window (seconds, no MSYS2 needed):
`powershell -ExecutionPolicy Bypass -File .\build-windows.ps1 -GuiOnly`.
The zip also carries a prebuilt copy; if SmartScreen warns about it, rebuild
it locally with that command (a locally built exe is not flagged).

`ppcosx.cmd` just starts `ppcosx.ps1` with the execution policy bypassed. Run
`.\ppcosx.cmd link` once to put the folder on your PATH, then type `ppcosx`
from anywhere.

Everything the bash launcher does is here with the same options: `run`,
`install`, `import`, `rom`, `new-disk`, `snapshot`, `doctor`, `update`, and
`--ram`, `--vram`, `--res`, `--vga`, `--jaguar`, `--attach-dvd`, `--verbose`,
`--snapshot`, `--ssh-port`, `--monitor`, `--rom`, and so on (`ppcosx help`).
Windows-only additions: `--display sdl|gtk`, `--vk-device N`, `--dry-run`,
`setup`, `gui`, `link`/`unlink`.

In the VM window, **Ctrl+Alt+G** releases the mouse.

## What `build-windows.ps1` does

1. Compiles `ppcosx-gui.exe` (a few seconds).
2. Installs MSYS2 (UCRT64) to `C:\msys64` if missing and updates it.
3. Installs the build dependencies with `pacman` (GCC, glib, pixman, SDL2,
   libslirp, shaderc, SPIRV-Cross, Vulkan headers and loader, ...).
4. Fetches the `qemu` submodule with LF line endings and applies
   `windows\patches\*.patch` to it.
5. Configures and builds QEMU for `ppc-softmmu`.
6. Installs into `win-qemu\`: `qemu-system-ppc.exe`, `qemu-img.exe`, and every
   DLL they need. That folder is self-contained; you can move it, and point the
   launcher at it with `PPCOSX_QEMU`.

Options: `-Clean` (rebuild from scratch), `-Jobs N`, `-SkipMsys2Update`,
`-Msys2Dir`, `-ResetMsys2`, `-GuiOnly`, `-NoGui`, `-NoPause`, `-DryRun`. Re-running is safe and incremental. The first build
needs internet access to github.com and gitlab.com (QEMU fetches a few small
subprojects while configuring).

## What was changed to make it build on Windows

`windows/patches/0001-windows-build-fixes.patch` touches the `qemu` submodule in
a few small places; nothing changes for macOS or Linux builds:

| File | Change | Why |
|---|---|---|
| `ui/meson.build` | build `poweremu-display.c` only when the host is not Windows | It is the bridge to the macOS PowerEmu app (Unix socket, `SCM_RIGHTS`, `mmap`). Nothing else depends on it. |
| `hw/display/ppc_mac_gpu.c` | `sched_yield()` becomes `g_thread_yield()` on Windows | MinGW has no `<sched.h>`. |
| `hw/display/ppc_mac_gpu.c` | fix the x86 (SSE2) byte-swap used to show the screen | The shipped routine threw away half of each pixel's bytes, so only the green channel survived: the grey boot screen showed as solid green. The ARM version (Apple Silicon) was fine, so it was never noticed. |
| `hw/display/ppc_mac_gpu.c` | `blit_path_log()` is a no-op on Windows | A developer logger that appends to `/tmp` on every blit; Windows has no `/tmp`. |
| `hw/display/ppc_mac_gpu.c` | the software renderer is only set up when no other renderer was | The `if (!s->renderer)` guarding it sat inside a `#ifdef CONFIG_DARWIN` block, so on every non-macOS host the software renderer was created unconditionally *after* the Vulkan one and replaced it. Quartz Extreme's 3D draws then went to a renderer that draws nothing: Tiger booted completely but the screen stayed on the Apple logo (the log said "using Vulkan renderer" and then "using software renderer"). |
| `python/scripts/mkvenv.py` | build the wheels folder URL with `Path.as_uri()` | QEMU wrote `file://C:/dir`, which pip reads as a host called `C:` and ignores, so configure could not install its bundled `meson`. Windows needs `file:///C:/dir` (identical result on Linux/macOS). |
| `configs/meson/windows.txt` | remove the default `prefix = '/qemu'` | With Python 3.13+ on Windows `/qemu` (no drive letter) is not an absolute path, so Meson rejects it when it regenerates the build files. Worse, Meson lets a machine-file value override the `--prefix` given on the command line whenever it regenerates, so the install folder would silently change too. |
| `meson.build` | skip `symlink-install-tree.py` on Windows | It makes a `qemu-bundle` tree of symlinks, which Windows only allows with Developer Mode or admin rights. An installed build doesn't use it. |

The launcher is a port of the bash `ppcosx`, including a native PowerShell
version of `tools/apm-wrap.py` (its output is byte-identical) and the ROM check.

### If the patch no longer applies

If the repo moves its `qemu` submodule to a newer commit and the patch fails,
make the same edits by hand (they are in the table above) and save them
as a new patch: `git -C qemu diff > windows/patches/0001-windows-build-fixes.patch`.

## Differences from macOS / Linux

* **3D renderer:** Vulkan only (see the table at the top for what that covers).
* **Window:** SDL (a resizable window that scales the screen). GTK is not built
  by default because it needs a large runtime tree.
* **Audio:** DirectSound. `--no-audio` turns it off.
* **`.dmg` installers:** the launcher asks QEMU to convert them, which works for
  some compression types but not all. If it can't, convert to `.iso`/`.cdr` once (on a Mac: `hdiutil convert in.dmg
  -format UDTO -o out`) or extract with 7-Zip.
* **Two GPUs (laptops):** the renderer prefers a discrete GPU. Force one with
  `--vk-device 0` or `--vk-device 1`, and make sure Windows is not restricting
  `qemu-system-ppc.exe` (Settings > System > Display > Graphics).

## Troubleshooting

**The VM window is solid green** (with a dark green Apple logo). That was a bug in
the emulator's x86 byte-swap, fixed by the patch (see the table above). Run
`build-windows.cmd` again; only one source file is recompiled, so it is quick.

**The picture does not change after "the Apple" appears.** The first boot of Tiger
under emulation is slow: several minutes on the grey Apple screen is normal, and
the Setup Assistant can take several more. If nothing changes after about 15
minutes, open Tools > Open QEMU log (last run), or `vm\qemu.log`, and send me its
last 50 lines. QEMU's messages are saved there instead of being shown in the
window, so the debug text can never slow the emulation down.

**The "Host GPU" list.** It now shows the GPUs the Vulkan runtime really reports,
by name. `ppcosx-gui.exe --list-gpus > gpus.txt` writes the same list to a file.
Some systems show extra entries (for example "Microsoft Direct3D12 ..." adapters
from Windows' Vulkan compatibility layer); pick your real GPU by its name.

Every run of `build-windows.ps1` writes everything it prints to
**`build-windows.log`** in the repo folder, so there is always a log to read
even if the window closes. (In the GUI: Tools > Open build log.)

**`error adding trust anchors from file: /usr/ssl/certs/ca-bundle.crt`, and
every `pacman` download fails.** MSYS2's first-run setup never finished (often
because the window was closed during the first run), so it has no certificate
bundle and can't verify any HTTPS mirror. `build-windows.ps1` now detects this
and repairs it: it runs MSYS2's own `update-ca-trust`, and if that isn't
enough it writes a bundle from Windows' trusted root certificates. If it still
fails, start MSYS2 over: `.\build-windows.ps1 -ResetMsys2` (deletes
`C:\msys64` and installs it fresh).

**The script window froze, then closed.** The MSYS2 download and extraction
are quiet for a minute or two, and when a script is started by double-click the
window closes the moment it ends. The script now prints progress while it
works, and when started by double-click it waits for Enter at the end. Start it
from a PowerShell prompt, or read `build-windows.log`.

**"Cannot reach mirror.msys2.org" / downloads time out.** MSYS2 and QEMU's
build need internet access to `msys2.org`, `github.com` and `gitlab.com`. A VPN,
proxy or firewall that blocks them will stop the build.

**`ppcosx doctor` says "no disk yet" although the GUI made one.** The GUI names each disk
after the VM (`vm\<name>.qcow2`). Doctor used to look only for `vm\macosx.qcow2`; it now lists
every disk in `vm\` and in `profiles.json`, with a warning if one is nearly empty.

**`ppcosx doctor` says the Vulkan renderer did not start and mentions audio.** Older
versions of the self-test started QEMU without any audio backend, so the mac99 machine's
sound chip failed with an audio error that was reported as a Vulkan failure. The test now
passes `-audio none` and uses the same AGP and NDRV settings as a real run, and the
"audio backend" line above it shows whether DirectSound/SDL sound is built in (sound being
unavailable never affects 3D). Run `ppcosx doctor` again: if the Vulkan check still fails,
the lines under it are QEMU's real error, including the Vulkan loader's driver-discovery
messages. `ppcosx doctor --vk-device 1` tests another GPU.

**Boot sticks on the Apple logo in Radeon/Vulkan mode but `--vga` boots.** This was the
renderer-replacement bug in the patch table above (check `vm\gpu-trace.log`: it must say
"using Vulkan renderer for 3D" and must *not* be followed by "using software renderer"). If you
still see it, run `build-windows.cmd` again so the updated patch is applied. Otherwise: Collect
information before guessing (`ppcosx diag` bundles the logs, VM files and system info into
`vm\diag.txt`, so you can attach one file): run `ppcosx --vk-debug --verbose`, let it sit on the logo for a
few minutes, close it, then read `vm\qemu.log` (QEMU's messages plus the Vulkan loader's) and
`vm\gpu-trace.log`. Things worth trying, one at a time: `--vk-device 0` / `--vk-device 1`
(`ppcosx-gui.exe --list-gpus` shows the numbers; avoid "Microsoft Direct3D12" entries),
`--vram 64`, `--ram 512`, and `--no-audio`.

**`ppcosx doctor` says the Vulkan renderer did not start.** Update your GPU
driver. Check that `C:\Windows\System32\vulkan-1.dll` exists. The message under
the failed check is QEMU's own error. `--vga` still works without 3D.

**"Repository path contains spaces" / path too long.** Move the repo to a short
path like `C:\ppcosxkvm`.

**`configure` fails with `$'\r': command not found`.** Files were checked out
with CRLF line endings. The build script repairs the `qemu` submodule itself;
for the rest, re-clone with `-c core.autocrlf=false` (the repo's new
`.gitattributes` also enforces this).

**`firmware checksums do not match`.** Same cause: CRLF conversion of
`firmware\SHA1SUMS` or the binaries.

**A required MSYS2 package is "not found".** Re-run without `-SkipMsys2Update`
so the package database is current.

**Build error mentioning a file path or `sys/mman.h`.** The patch did not
apply; see "If the patch no longer applies".

**Windows Defender is slow / blocks the build.** Excluding the repo folder and
`C:\msys64` from real-time scanning makes the compile noticeably faster.

**Black screen or no Apple logo.** Try `--vga`, then `--verbose` to see the
boot text, then `--vram 64`.

**Dozens of `error: ... [-Werror=...]` compile failures (unused variable, "might be a
candidate for 'gnu_printf'", and so on).** `-Werror` (treat warnings as errors)
was switched back on. QEMU's `configure` writes `werror = true` into a machine
file, and Meson lets that override the `--disable-werror` we pass whenever it
regenerates the build files (an MSYS2 compiler update is enough to cause it), so
the newer GCC's extra warnings became errors. `build-windows.ps1` v7 removes that
line and pins `werror=false` and the install prefix after every configure, which
also repairs a build folder that is already in that state. Expect a large part of
QEMU to recompile once, because the compiler flags change back.

**The build fails right at the start with `prefix value '/qemu' must be an absolute
path` / `rebuilding 'build.ninja'`.** The `windows.txt` row in the patch table
fixes this. It appears when something makes Meson regenerate (an MSYS2 update,
or a changed `meson.build`). `build-windows.ps1` v6 and later repair it
automatically; check that the log starts with `build-windows.ps1 v6`.

**The build stops at `tests/unit/test-vmstate.exe` ("undefined reference to
`qemu_ftruncate64`").** That is one of QEMU's own unit-test programs, which does
not link on Windows (an upstream bug) and is not needed. `build-windows.ps1`
v5 and later keep building past failing test programs and only stop if
something outside `tests/` fails. Re-running resumes where it stopped.

**configure fails with "Could not find a version that satisfies the requirement
meson==1.5.0" / "Location 'file://C:/...' is ignored".** The `mkvenv.py` row in
the patch table fixes this; it means the patch was not applied. Re-extract the
zip over the repo (choose Replace) and run `build-windows.cmd` again.

## Reporting problems

Run `ppcosx doctor` and include its output plus `build-windows.log` (and
`win-build\ppcosx-build.log` if it exists) for build failures, or the console
output of the run for runtime ones.
