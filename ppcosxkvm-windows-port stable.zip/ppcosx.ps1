# ppcosx.ps1 - run PowerPC Mac OS X (Tiger) on Windows with an emulated
# ATI Radeon 9700 PRO whose 3D engine is translated to Vulkan.
#
# This is the Windows port of the bash launcher "ppcosx": same commands, same
# options.  Windows PowerShell 5.1 and PowerShell 7+ both work.
#
#   .\ppcosx.ps1 help        (or  ppcosx help  via ppcosx.cmd)
#   docs\WINDOWS.md          for the long version
#
# No param() block on purpose: options look like the bash version's (--ram 2048).
Set-StrictMode -Version 2.0
$ErrorActionPreference = 'Stop'

$ScriptArgs = @($args)
$IsWin = ($env:OS -eq 'Windows_NT')
$Repo = $PSScriptRoot
function P { [System.IO.Path]::Combine([string[]]$args) }

$VmDir = if ($env:PPCOSX_VM_DIR) { $env:PPCOSX_VM_DIR } else { P $Repo 'vm' }
$WinQemuDir = P $Repo 'win-qemu'
$exeExt = if ($IsWin) { '.exe' } else { '' }
if ($env:PPCOSX_QEMU) {
    $Qemu = $env:PPCOSX_QEMU
    $QemuHome = Split-Path $Qemu -Parent
} else {
    $QemuHome = $WinQemuDir
    $Qemu = P $QemuHome ("qemu-system-ppc$exeExt")
}
$QemuImgExe = P $QemuHome ("qemu-img$exeExt")
$QemuData = P $QemuHome 'share'
$FwRadeon = P $Repo 'firmware' 'radeon'
$FwJaguar = P $Repo 'firmware' 'jaguar'
$FwVga = P $Repo 'firmware' 'vga'
$DiskDefault = P $VmDir 'macosx.qcow2'
$RomDefault = P $VmDir 'roms' 'radeon9700.rom'
$CpuMhzDefault = 2000
$ModelDefault = 'PowerBook5,8'
$RadeonSlot = 'e'
$Prog = '.\ppcosx.ps1'
if (Get-Command ppcosx -ErrorAction SilentlyContinue) { $Prog = 'ppcosx' }

# ---------------------------------------------------------------- output ---
function Say([string]$m)  { Write-Host "==> $m" -ForegroundColor Cyan }
function Ok([string]$m)   { Write-Host "  OK $m" -ForegroundColor Green }
function Warn([string]$m) { Write-Host "  !! $m" -ForegroundColor Yellow }
function Bad([string]$m)  { Write-Host "  XX $m" -ForegroundColor Red }
function Hint([string]$m) { Write-Host "     $m" -ForegroundColor DarkGray }
function Die([string]$m)  { Write-Host "error: $m" -ForegroundColor Red; exit 1 }

# ---------------------------------------------------------------- helpers ---
function Rel([string]$p) {
    if ($p.StartsWith($Repo, [StringComparison]::OrdinalIgnoreCase)) { return $p.Substring($Repo.Length).TrimStart('\', '/') }
    return $p
}

function Abs([string]$p) {   # resolve against the PowerShell location, not the process directory
    $ExecutionContext.SessionState.Path.GetUnresolvedProviderPathFromPSPath($p)
}

# One argument, quoted the way the Windows C runtime (and .NET on Linux) parses it back.
function Quote-Arg([string]$a) {
    if ($a.Length -gt 0 -and $a -notmatch '[\s"]') { return $a }
    $sb = New-Object System.Text.StringBuilder
    [void]$sb.Append('"')
    $bs = 0
    foreach ($c in $a.ToCharArray()) {
        if ($c -eq [char]'\') { $bs++ }
        elseif ($c -eq [char]'"') { [void]$sb.Append('\' * ($bs * 2 + 1)); [void]$sb.Append('"'); $bs = 0 }
        else { if ($bs -gt 0) { [void]$sb.Append('\' * $bs); $bs = 0 }; [void]$sb.Append($c) }
    }
    if ($bs -gt 0) { [void]$sb.Append('\' * ($bs * 2)) }
    [void]$sb.Append('"')
    $sb.ToString()
}

function Join-Args([string[]]$Argv) { (@($Argv | ForEach-Object { Quote-Arg $_ })) -join ' ' }

# Inside a QEMU "key=value,key=value" option a literal comma is written ",,".
function Esc-Opt([string]$s) { $s -replace ',', ',,' }

# Run a program to completion and return its combined output (no console window games).
function Invoke-Capture([string]$Exe, [string[]]$Argv, [int]$TimeoutMs = 60000) {
    $psi = New-Object System.Diagnostics.ProcessStartInfo
    $psi.FileName = $Exe
    $psi.Arguments = Join-Args $Argv
    $psi.UseShellExecute = $false
    $psi.RedirectStandardOutput = $true
    $psi.RedirectStandardError = $true
    $psi.CreateNoWindow = $true
    $p = [System.Diagnostics.Process]::Start($psi)
    $o = $p.StandardOutput.ReadToEndAsync()
    $e = $p.StandardError.ReadToEndAsync()
    if (-not $p.WaitForExit($TimeoutMs)) { try { $p.Kill() } catch {}; return @{ Code = -1; Text = 'timed out' } }
    $p.WaitForExit()
    return @{ Code = $p.ExitCode; Text = ($o.Result + $e.Result) }
}

# Run QEMU and return its exit code.
# QEMU's console output (the GPU model prints a lot of debug text) goes to vm\qemu.log rather than
# the console or the GUI's pipe: a slow reader there can stall the whole emulated machine.
# Use --console-log to see it live instead.
function Start-Qemu([string[]]$Argv, [hashtable]$EnvVars) {
    if ($script:DryRun) {
        Write-Host ((Quote-Arg $Qemu) + ' ' + (Join-Args $Argv))
        return 0
    }
    $psi = New-Object System.Diagnostics.ProcessStartInfo
    $psi.FileName = $Qemu
    $psi.Arguments = Join-Args $Argv
    $psi.UseShellExecute = $false
    foreach ($k in $EnvVars.Keys) { $psi.EnvironmentVariables[$k] = $EnvVars[$k] }
    if ($script:ConsoleLog) {
        $p = [System.Diagnostics.Process]::Start($psi)
        $p.WaitForExit()
        return $p.ExitCode
    }
    $logPath = P $VmDir 'qemu.log'
    New-Item -ItemType Directory -Force -Path $VmDir | Out-Null
    $psi.RedirectStandardOutput = $true
    $psi.RedirectStandardError = $true
    $fs = [System.IO.File]::Open($logPath, [System.IO.FileMode]::Create, [System.IO.FileAccess]::Write, [System.IO.FileShare]::ReadWrite)
    $sync = [System.IO.Stream]::Synchronized($fs)
    $p = [System.Diagnostics.Process]::Start($psi)
    $t1 = $p.StandardOutput.BaseStream.CopyToAsync($sync)
    $t2 = $p.StandardError.BaseStream.CopyToAsync($sync)
    Write-Host "     QEMU's messages are saved in $(Rel $logPath)" -ForegroundColor DarkGray
    $p.WaitForExit()
    [void]$t1.Wait(5000); [void]$t2.Wait(5000)
    $sync.Flush(); $fs.Close()
    $rc = $p.ExitCode
    if ($rc -ne 0) {
        Write-Host "  !! QEMU exited with code $rc. Last lines of its log:" -ForegroundColor Yellow
        Get-Content -Path $logPath -Tail 25 -ErrorAction SilentlyContinue | ForEach-Object { Write-Host "     $_" -ForegroundColor DarkGray }
    }
    return $rc
}

function Qemu-Img([string[]]$Argv) {
    $exe = $QemuImgExe
    if (-not (Test-Path $exe)) {
        $cmd = Get-Command qemu-img -ErrorAction SilentlyContinue
        if ($cmd) { $exe = $cmd.Source } else { Die "qemu-img not found - run $Prog setup first" }
    }
    $psi = New-Object System.Diagnostics.ProcessStartInfo
    $psi.FileName = $exe
    $psi.Arguments = Join-Args $Argv
    $psi.UseShellExecute = $false
    $p = [System.Diagnostics.Process]::Start($psi)
    $p.WaitForExit()
    return $p.ExitCode
}

function Qemu-Img-Capture([string[]]$Argv) {
    $exe = $QemuImgExe
    if (-not (Test-Path $exe)) { $cmd = Get-Command qemu-img -ErrorAction SilentlyContinue; if ($cmd) { $exe = $cmd.Source } else { Die "qemu-img not found - run $Prog setup first" } }
    return (Invoke-Capture $exe $Argv)
}

function Need-Qemu { if (-not (Test-Path $Qemu)) { Die "QEMU is not built yet. Run:  $Prog setup" } }

function Human-Size([double]$b) {
    $u = 'B', 'KB', 'MB', 'GB', 'TB'; $i = 0
    while ($b -ge 1024 -and $i -lt 4) { $b /= 1024; $i++ }
    ('{0:N0} {1}' -f $b, $u[$i])
}

function Disk-Size([string]$disk) {   # virtual size in bytes, or 0
    $r = Qemu-Img-Capture @('info', '-U', '--output=json', $disk)
    if ($r.Code -ne 0) { return 0 }
    try { return [double](($r.Text | ConvertFrom-Json).'virtual-size') } catch { return 0 }
}

function Disk-InUse([string]$disk) {
    try {
        $procs = @(Get-CimInstance Win32_Process -Filter "Name LIKE 'qemu-system-ppc%'" -ErrorAction Stop)
    } catch { return $false }
    $needle = 'file.filename=' + (Esc-Opt $disk) + ','
    foreach ($p in $procs) {
        if ($p.CommandLine -and $p.CommandLine.IndexOf($needle, [StringComparison]::OrdinalIgnoreCase) -ge 0) { return $true }
    }
    return $false
}

function Port-Free([int]$port) {
    try {
        $l = New-Object System.Net.Sockets.TcpListener([System.Net.IPAddress]::Loopback, $port)
        $l.Start(); $l.Stop(); return $true
    } catch { return $false }
}

$script:ProbeCache = @{}
function Qemu-Probe([string]$key, [string[]]$Argv) {
    if (-not $script:ProbeCache.ContainsKey($key)) {
        $script:ProbeCache[$key] = (Invoke-Capture $Qemu $Argv 15000).Text
    }
    return $script:ProbeCache[$key]
}

# ------------------------------------------------------------------ help ---
function Show-Usage {
@"
ppcosx - PowerPC Mac OS X (Tiger) on Windows, with an emulated ATI Radeon 9700 PRO
(Quartz Extreme, Core Image and OpenGL via Vulkan).

First time
  ppcosx setup                 build qemu-system-ppc.exe (runs build-windows.ps1)
  ppcosx install <tiger.iso>   install Mac OS X from a DVD image (.iso .cdr .dmg .toast)
    or
  ppcosx import <disk>         use an existing PowerPC OS X disk
                               (.qcow2 .vmdk .vdi .vhd .img .utm bundle)
  ppcosx rom <file.rom>        (optional) your Mac Radeon 9700 PRO ROM

Every day
  ppcosx                       boot the VM with the Radeon 9700 (3D acceleration)
  ppcosx --vga                 boot with a plain framebuffer (safe mode)
  ppcosx --jaguar              Mac OS X 10.2 Jaguar (Radeon 9000; software 3D on Windows)
  ppcosx --attach-dvd <file>   boot with a DVD/CD image inserted
  ppcosx --ram 2048 --verbose  any run option works directly (see below)
  ppcosx doctor [--vk-device N]  check that everything is in place (and test Vulkan)
  ppcosx gui                   open the graphical front-end (ppcosx-gui.exe)
  ppcosx diag                  save logs and system info to vm\diag.txt (for bug reports)

Disks
  ppcosx new-disk [size] [path]  create an empty disk (default 40G at vm\macosx.qcow2)
  ppcosx snapshot list|save|restore|delete [name] [--disk PATH]
                               disk snapshots (VM must be shut down)

Maintenance
  ppcosx update                git pull, then rebuild
  ppcosx setup [--clean]       (re)build QEMU;  --jobs N sets compile jobs
  ppcosx link | unlink         add or remove this folder on your user PATH

Run options (for "ppcosx", "ppcosx run" and "ppcosx install")
  --disk PATH      disk image to boot        (default: vm\macosx.qcow2)
  --ram MB         guest memory, 256-2048    (default: 1024)
  --cpu-mhz N      CPU speed Mac OS X sees   (default: $CpuMhzDefault; reporting only)
  --model NAME     Mac model Mac OS X sees   (default: $ModelDefault; "default" = PowerMac3,1)
  --vram MB        Radeon video memory 64/128/256 (default: 128)
  --res WxH        screen size               (default: 1024x768)
  --rom PATH       Radeon ROM to use         (default: vm\roms\radeon9700.rom if present)
  --no-rom         boot without the ROM, even if one is installed
  --vga            plain framebuffer instead of the Radeon
  --jaguar         Mac OS X 10.2 Jaguar (also --card 9000). Tiger and Leopard get full GPU
                   acceleration through Vulkan; Jaguar's older 3D engine is software-only here
  --gpu vulkan     host 3D API (default). --gpu software: no host 3D, for diagnosing
  --display D      auto (default), sdl or gtk
  --vk-device N    use Vulkan device N (default: the first discrete GPU, else integrated)
  --vk-debug       log the Vulkan loader's driver/GPU discovery messages to vm\qemu.log
  --attach-dvd IMG DVD/CD image to insert (also --dvd)
  --verbose        verbose (text) boot instead of the grey Apple
  --snapshot       throw away all disk writes when the VM quits
  --no-audio       no sound
  --ssh-port N     forward host 127.0.0.1:N to guest port 22
  --monitor        QEMU monitor on 127.0.0.1:4444 (HMP) and :4445 (QMP)
  --trace-gpu      log every GPU register access to vm\gpu-trace.log (slow)
  --dry-run        print the QEMU command line instead of starting it
  --console-log    show QEMU's messages here instead of saving them to vm\qemu.log
  -- ARGS...       pass the remaining arguments straight to QEMU

Files live in $VmDir (override with PPCOSX_VM_DIR).
Program: $Repo
"@ | Write-Host
}

# ----------------------------------------------------------------- setup ---
function Cmd-Setup([string[]]$A) {
    $h = @{}
    for ($i = 0; $i -lt $A.Count; $i++) {
        switch ($A[$i]) {
            { $_ -in '--clean', '--build' } { if ($_ -eq '--clean') { $h['Clean'] = $true } }
            '--jobs' { $i++; $h['Jobs'] = [int]$A[$i] }
            '--skip-update' { $h['SkipMsys2Update'] = $true }
            default { Die "usage: $Prog setup [--clean] [--jobs N] [--skip-update]" }
        }
    }
    & (P $Repo 'build-windows.ps1') @h
    if (-not (Test-Path (P $VmDir 'roms'))) { New-Item -ItemType Directory -Force -Path (P $VmDir 'roms') | Out-Null }
}

# ---------------------------------------------------------------- doctor ---
function Rom-Check([string]$path) {   # returns a description, or throws with the reason
    $d = [System.IO.File]::ReadAllBytes($path)
    if ($d.Length -lt 0x40 -or $d[0] -ne 0x55 -or $d[1] -ne 0xAA) { throw 'not a PCI option ROM (no 55 AA signature)' }
    $p = [BitConverter]::ToUInt16($d, 0x18)
    if ($p + 0x15 -ge $d.Length -or [System.Text.Encoding]::ASCII.GetString($d, $p, 4) -ne 'PCIR') { throw 'no PCI data structure' }
    $ven = [BitConverter]::ToUInt16($d, $p + 4)
    $dev = [BitConverter]::ToUInt16($d, $p + 6)
    $code = $d[$p + 0x14]
    if ($ven -ne 0x1002) { throw ('vendor {0:x4} is not ATI' -f $ven) }
    if ($dev -ne 0x4e44) { throw ('device {0:x4}:{1:x4} is not a Radeon 9700 PRO (1002:4e44)' -f $ven, $dev) }
    if ($code -ne 1) { throw "this is a PC ROM (code type $code); a Mac (Open Firmware) ROM is needed" }
    ('{0:x4}:{1:x4}, Open Firmware, {2} KB' -f $ven, $dev, [int]($d.Length / 1024))
}

function Test-Vulkan3D([string]$VkDevice = '') {   # start the emulated card headless, paused, and see if the renderer comes up
    # Mirror the real run: the mac99 machine has a sound chip that needs an audio backend even
    # under -nodefaults ("-audio none" is enough), and the Radeon is created with the same AGP
    # setting and NDRV driver as in Cmd-Run.  Without these the test died on an audio error
    # that was reported as "the Vulkan 3D renderer did not start".
    $argv = @('-L', $FwRadeon, '-L', $QemuData, '-nodefaults', '-vga', 'none', '-machine', 'mac99,via=pmu',
              '-accel', 'tcg', '-m', '256', '-display', 'none', '-audio', 'none', '-S',
              '-global', 'uni-north-pci.agp-capable=on',
              '-device', 'ati-radeon-9700,addr=e.0,vgamem_mb=64,renderer=vulkan,romfile=')
    $psi = New-Object System.Diagnostics.ProcessStartInfo
    $psi.FileName = $Qemu
    $psi.Arguments = Join-Args $argv
    $psi.UseShellExecute = $false
    $psi.RedirectStandardError = $true
    $psi.RedirectStandardOutput = $true
    $psi.CreateNoWindow = $true
    $psi.EnvironmentVariables['QEMU_PPC_NDRV'] = (P $FwRadeon 'qemu_vga_hwc.ndrv')
    $psi.EnvironmentVariables['VK_LOADER_DEBUG'] = 'error,warn'
    $psi.EnvironmentVariables['VK_LOADER_LAYERS_DISABLE'] = '~implicit~'
    if ($VkDevice) { $psi.EnvironmentVariables['PPCGPU_VK_DEVICE'] = $VkDevice }
    $p = [System.Diagnostics.Process]::Start($psi)
    $e = $p.StandardError.ReadToEndAsync(); $o = $p.StandardOutput.ReadToEndAsync()
    if ($p.WaitForExit(15000)) {
        return @{ Ok = $false; Text = (("exit code $($p.ExitCode)`n" + $e.Result + $o.Result).Trim()) }
    }
    try { $p.Kill() } catch {}
    return @{ Ok = $true; Text = '' }
}

function Cmd-Doctor([string[]]$A) {
    $fail = 0
    $vkDev = ''
    for ($i = 0; $i -lt $A.Count; $i++) { if ($A[$i] -eq '--vk-device' -and ($i + 1) -lt $A.Count) { $vkDev = $A[$i + 1]; $i++ } }
    Say 'Host'
    if ($IsWin) {
        $os = (Get-CimInstance Win32_OperatingSystem -ErrorAction SilentlyContinue)
        if ($os) { Ok "$($os.Caption) (build $($os.BuildNumber))" }
        if (-not [Environment]::Is64BitOperatingSystem) { Bad '64-bit Windows is required'; $fail = 1 }
        $gpus = @(Get-CimInstance Win32_VideoController -ErrorAction SilentlyContinue)
        foreach ($g in $gpus) { Ok "GPU: $($g.Name) (driver $($g.DriverVersion))" }
        if ($gpus.Count -eq 0) { Warn 'could not list graphics adapters' }
        if (Test-Path (P $env:windir 'System32' 'vulkan-1.dll')) { Ok 'Vulkan runtime (vulkan-1.dll) installed by your GPU driver' }
        else { Warn 'vulkan-1.dll not found in System32: update your GPU driver (NVIDIA, AMD or Intel) for Vulkan'; }
    } else { Warn "this is not Windows; use ./ppcosx" }

    Say 'Emulator'
    if (Test-Path $Qemu) {
        $v = (Invoke-Capture $Qemu @('--version') 15000).Text
        Ok (($v -split "`r?`n")[0])
        if ((Qemu-Probe 'devices' @('-device', 'help')) -match 'ati-radeon-9700') { Ok 'ati-radeon-9700 device present' }
        else { Bad 'this QEMU has no ati-radeon-9700 device'; $fail = 1 }
        $disp = Qemu-Probe 'display' @('-display', 'help')
        if ($disp -match '(?m)^\s*sdl\s*$') { Ok 'SDL display' } elseif ($disp -match '(?m)^\s*gtk\s*$') { Ok 'GTK display' } else { Warn 'neither SDL nor GTK display is built in' }
        $aud = Qemu-Probe 'audio' @('-audiodev', 'help')
        if ($aud -match '\bdsound\b') { Ok 'audio backend: DirectSound' }
        elseif ($aud -match '\bsdl\b') { Ok 'audio backend: SDL' }
        else { Warn 'no audio backend built into this QEMU (sound will be off; this does not affect 3D)' }
        $t = Test-Vulkan3D $vkDev
        if ($t.Ok) { Ok 'Vulkan 3D renderer starts' }
        else {
            Bad 'the Vulkan 3D renderer did not start. QEMU said:'
            foreach ($l in ($t.Text -split "`r?`n")) { Hint $l }
            if ($t.Text -match '(?i)audio' -and $t.Text -notmatch '(?i)vulkan|renderer|shader|spirv|vk') {
                Hint '(that is an audio message, not a Vulkan one: try  ppcosx --no-audio  to confirm)'
            }
            $fail = 1
        }
    } else {
        Bad 'QEMU not built'; Hint "$Prog setup"; $fail = 1
    }
    foreach ($f in @((P $FwRadeon 'openbios-ppc'), (P $FwRadeon 'ppc-ndrvloader'), (P $FwRadeon 'qemu_vga_hwc.ndrv'),
                     (P $FwVga 'openbios-ppc'), (P $FwVga 'ppc-ndrvloader'))) {
        if (-not (Test-Path $f)) { Bad "missing $(Rel $f)"; $fail = 1 }
    }
    $sums = P $Repo 'firmware' 'SHA1SUMS'
    if (Test-Path $sums) {
        $sumBad = 0
        foreach ($line in (Get-Content $sums)) {
            if ($line -match '^([0-9a-fA-F]{40})\s+\*?(.+?)\s*$') {
                $fp = P $Repo 'firmware' ($Matches[2] -replace '/', [string][System.IO.Path]::DirectorySeparatorChar)
                if (-not (Test-Path $fp) -or (Get-FileHash -Algorithm SHA1 $fp).Hash.ToLower() -ne $Matches[1].ToLower()) { $sumBad = 1 }
            }
        }
        if ($sumBad -eq 0) { Ok 'firmware checksums' }
        else { Bad 'firmware checksums do not match firmware\SHA1SUMS'; Hint 'was the repo cloned with CRLF conversion? use: git clone -c core.autocrlf=false ...'; $fail = 1 }
    }

    Say "Your files ($VmDir)"
    # The GUI names each VM's disk after the VM (vm\<name>.qcow2) and passes it with --disk, so look
    # at every disk in the folder and in profiles.json, not only at the default vm\macosx.qcow2.
    $found = @()
    foreach ($f in @(Get-ChildItem -Path $VmDir -Filter '*.qcow2' -File -ErrorAction SilentlyContinue)) { $found += $f.FullName }
    $pj = P $VmDir 'profiles.json'
    if (Test-Path $pj) {
        try {
            $arr = Get-Content -Path $pj -Raw | ConvertFrom-Json
            foreach ($pr in @($arr)) {
                $dp = $pr.PSObject.Properties['Disk']
                if ($dp -and $dp.Value -and (Test-Path ([string]$dp.Value))) { $found += [string]$dp.Value }
            }
        } catch { }
    }
    $seen = @{}; $nDisks = 0
    foreach ($d in $found) {
        $k = $d.ToLower()
        if ($seen.ContainsKey($k)) { continue }
        $seen[$k] = 1; $nDisks++
        $len = (Get-Item $d).Length
        Ok "disk $(Rel $d): $(Human-Size (Disk-Size $d)) virtual, $(Human-Size $len) used so far"
        if ($len -lt 500MB) { Warn 'that disk is nearly empty: the Mac OS X install probably did not finish'; Hint "run the installer again (it will reuse this disk)" }
    }
    if ($nDisks -eq 0) { Warn 'no disk yet'; Hint "$Prog install <iso>   or   $Prog import <disk>" }
    if (Test-Path $RomDefault) {
        try { Ok "Radeon ROM $(Rom-Check $RomDefault)" } catch { Bad "vm\roms\radeon9700.rom is not a Mac Radeon 9700 ROM"; $fail = 1 }
    } else { Ok 'no Radeon ROM (optional)' }
    Write-Host ''
    if ($fail -eq 0) { Say 'All good.' } else { Say 'Some checks failed - see above.' }
    exit $fail
}

# ------------------------------------------------------------------- rom ---
function Cmd-Rom([string[]]$A) {
    if ($A.Count -lt 1) { Die "usage: $Prog rom <file.rom>   (or: $Prog rom --remove)" }
    if ($A[0] -eq '--remove') { Remove-Item -Force -ErrorAction SilentlyContinue $RomDefault; Ok 'ROM removed; the Radeon runs without one'; return }
    $src = Abs $A[0]
    if (-not (Test-Path $src)) { Die "no such file: $src" }
    try { $info = Rom-Check $src } catch { Die "${src}: $($_.Exception.Message)" }
    New-Item -ItemType Directory -Force -Path (P $VmDir 'roms') | Out-Null
    Copy-Item -Force $src $RomDefault
    Ok "installed ROM ($info) as $(Rel $RomDefault)"
}

# -------------------------------------------------------------- new-disk ---
function Cmd-NewDisk([string[]]$A) {
    $size = if ($A.Count -ge 1) { $A[0] } else { '40G' }
    $disk = if ($A.Count -ge 2) { Abs $A[1] } else { $DiskDefault }
    New-DiskFile $size $disk
}

function New-DiskFile([string]$size, [string]$disk) {
    if (Test-Path $disk) { Die "$disk already exists (delete it first to start over)" }
    New-Item -ItemType Directory -Force -Path (Split-Path $disk -Parent) | Out-Null
    $rc = Qemu-Img @('create', '-q', '-f', 'qcow2', '-o', 'lazy_refcounts=on,preallocation=metadata', $disk, $size)
    if ($rc -ne 0) { Die 'qemu-img create failed' }
    Ok "created empty $size disk $(Rel $disk)"
}

# ---------------------------------------------------------------- import ---
function Cmd-Import([string[]]$A) {
    $force = $false; $src = ''; $dst = $DiskDefault
    for ($i = 0; $i -lt $A.Count; $i++) {
        switch -Regex ($A[$i]) {
            '^--force$' { $force = $true; break }
            '^--as$' { $i++; $dst = Abs $A[$i]; break }
            '^-' { Die "unknown option $($A[$i])" }
            default { $src = $A[$i] }
        }
    }
    if (-not $src) { Die "usage: $Prog import <disk image or .utm bundle> [--as out.qcow2] [--force]" }
    if (-not (Test-Path $src)) { Die "no such file: $src" }
    $src = Abs $src
    if (Test-Path $src -PathType Container) {   # UTM bundle: the largest disk image in Data\
        $c = @(Get-ChildItem -Path (P $src 'Data') -File -ErrorAction SilentlyContinue | Where-Object { $_.Extension -in '.qcow2', '.img' } | Sort-Object Length -Descending)
        if ($c.Count -eq 0) { Die "$src has no Data\*.qcow2 or Data\*.img disk" }
        Say "Using the UTM disk $($c[0].Name)"
        $src = $c[0].FullName
    }
    if ($src -match '(?i)\.(dmg|iso|cdr|toast)$') { Die "$(Split-Path $src -Leaf) looks like an installer; use: $Prog install `"$src`"" }
    if ((Test-Path $dst) -and -not $force) { Die "$(Rel $dst) already exists. Use --force to replace it, or --as other.qcow2" }
    Say "Converting $(Split-Path $src -Leaf) to $(Rel $dst) (your original is not modified)"
    New-Item -ItemType Directory -Force -Path (Split-Path $dst -Parent) | Out-Null
    $rc = Qemu-Img @('convert', '-p', '-O', 'qcow2', $src, "$dst.part")
    if ($rc -ne 0) { Remove-Item -Force -ErrorAction SilentlyContinue "$dst.part"; Die 'conversion failed' }
    Move-Item -Force "$dst.part" $dst
    Ok 'imported'
    $extra = if ($dst -ne $DiskDefault) { " --disk `"$dst`"" } else { '' }
    Hint "Boot it:  $Prog run$extra"
    Hint "(Mac OS X 10.2 Jaguar? Boot it with  $Prog --jaguar$extra )"
}

# ------------------------------------------------------------- snapshots ---
function Cmd-Snapshot([string[]]$A) {
    $disk = $DiskDefault
    $plain = @()
    for ($i = 0; $i -lt $A.Count; $i++) {          # --disk PATH may appear anywhere
        if ($A[$i] -eq '--disk' -and ($i + 1) -lt $A.Count) { $disk = Abs $A[$i + 1]; $i++ }
        else { $plain += $A[$i] }
    }
    $action = if ($plain.Count -ge 1) { $plain[0] } else { 'list' }
    $rest = @(if ($plain.Count -ge 2) { $plain[1..($plain.Count - 1)] })
    if (-not (Test-Path $disk)) { Die "no disk at $(Rel $disk)" }
    if (Disk-InUse $disk) { Die 'the VM is running; shut it down first' }
    switch ($action) {
        'list'    { [void](Qemu-Img @('snapshot', '-l', $disk)) }
        'save'    { if ($rest.Count -ne 1) { Die "usage: $Prog snapshot save <name>" }
                    if ((Qemu-Img @('snapshot', '-c', $rest[0], $disk)) -eq 0) { Ok "saved snapshot '$($rest[0])'" } }
        'restore' { if ($rest.Count -ne 1) { Die "usage: $Prog snapshot restore <name>" }
                    if ((Qemu-Img @('snapshot', '-a', $rest[0], $disk)) -eq 0) { Ok "disk restored to '$($rest[0])'" } }
        'delete'  { if ($rest.Count -ne 1) { Die "usage: $Prog snapshot delete <name>" }
                    if ((Qemu-Img @('snapshot', '-d', $rest[0], $disk)) -eq 0) { Ok "deleted snapshot '$($rest[0])'" } }
        default   { Die "usage: $Prog snapshot list|save|restore|delete [name]" }
    }
}

# ------------------------------------------------------------ DVD images ---
# A retail Leopard DVD image is one bare HFS+ volume.  OpenBIOS only boots a
# disc whose volume is in an Apple_HFS partition, so give such an image a
# partition map once.  (Native port of tools\apm-wrap.py.)
function Test-BareHfs([string]$path) {
    $fs = [System.IO.File]::OpenRead($path)
    try { $buf = New-Object byte[] 1026; $n = $fs.Read($buf, 0, 1026) } finally { $fs.Close() }
    if ($n -lt 1026) { return $false }
    if ($buf[0] -eq 0x45 -and $buf[1] -eq 0x52) { return $false }      # 'ER': already partitioned
    $t = [string][char]$buf[1024] + [char]$buf[1025]
    return ($t -eq 'H+' -or $t -eq 'HX' -or $t -eq 'BD')
}

function Add-PartitionMap([string]$src, [string]$dst) {
    $BS = 512; $MAP = 64
    $vol = [uint32]([math]::Floor((Get-Item $src).Length / $BS))
    function BE([System.IO.MemoryStream]$ms, [uint64]$v, [int]$bytes) {
        for ($i = $bytes - 1; $i -ge 0; $i--) { $ms.WriteByte([byte](($v -shr (8 * $i)) -band 0xFF)) }
    }
    function Pad([System.IO.MemoryStream]$ms, [int]$to) { while ($ms.Length -lt $to) { $ms.WriteByte(0) } }
    function Str([System.IO.MemoryStream]$ms, [string]$s, [int]$len) {
        $b = [System.Text.Encoding]::ASCII.GetBytes($s); $ms.Write($b, 0, $b.Length)
        for ($i = $b.Length; $i -lt $len; $i++) { $ms.WriteByte(0) }
    }
    $m = New-Object System.IO.MemoryStream
    Str $m 'ER' 2; BE $m $BS 2; BE $m ($MAP + $vol) 4; Pad $m $BS
    foreach ($e in @(@(1, ($MAP - 1), 'Apple', 'Apple_partition_map', 3), @($MAP, $vol, 'Mac_OS_X', 'Apple_HFS', 0x7F))) {
        $start = $m.Length
        Str $m 'PM' 2; BE $m 0 2; BE $m 2 4; BE $m $e[0] 4; BE $m $e[1] 4
        Str $m $e[2] 32; Str $m $e[3] 32; BE $m 0 4; BE $m $e[1] 4; BE $m $e[4] 4
        Pad $m ($start + $BS)
    }
    Pad $m ($MAP * $BS)
    $out = [System.IO.File]::Create($dst)
    try {
        $m.WriteTo($out)
        $in = [System.IO.File]::OpenRead($src)
        try { $in.CopyTo($out, 16MB) } finally { $in.Close() }
    } finally { $out.Close() }
}

function Resolve-Dvd([string]$src) {   # returns the path QEMU should read
    if (-not (Test-Path $src)) { Die "no such DVD image: $src" }
    New-Item -ItemType Directory -Force -Path $VmDir | Out-Null
    $base = [System.IO.Path]::GetFileNameWithoutExtension($src)
    $cdr = P $VmDir "dvd-$base.cdr"
    $path = $src
    if ($src -match '(?i)\.dmg$') {
        if (-not (Test-Path $cdr) -or (Get-Item $src).LastWriteTime -gt (Get-Item $cdr).LastWriteTime) {
            Say "Converting $(Split-Path $src -Leaf) to a raw DVD image (one time)"
            Remove-Item -Force -ErrorAction SilentlyContinue $cdr
            $rc = Qemu-Img @('convert', '-p', '-f', 'dmg', '-O', 'raw', $src, $cdr)
            if ($rc -ne 0) {
                Remove-Item -Force -ErrorAction SilentlyContinue $cdr
                Die ("QEMU could not read $(Split-Path $src -Leaf) (some .dmg compression types are unsupported). " +
                     'Convert it to .iso/.cdr first: on a Mac with  hdiutil convert in.dmg -format UDTO -o out  , or extract it with 7-Zip.')
            }
        }
        $path = $cdr
    }
    if (Test-BareHfs $path) {
        if ($path -eq $cdr -or -not (Test-Path $cdr) -or (Get-Item $src).LastWriteTime -gt (Get-Item $cdr).LastWriteTime) {
            Say "Adding a partition map to $(Split-Path $src -Leaf) so OpenBIOS can boot it (one time)"
            $tmp = "$cdr.part"
            $final = $cdr
            if ($path -eq $cdr) { $tmp = "$cdr.wrap" }
            Add-PartitionMap $path $tmp
            Move-Item -Force $tmp $final
        }
        $path = $cdr
    }
    return $path
}

# ------------------------------------------------------------------- run ---
function Get-ModelForth([string]$Model) {
    if (-not $Model) { return '' }
    $q = '"'
    $parts = @(
        "$q /$q find-device",
        "$q $Model$q encode-string",
        "$q MacRISC$q encode-string encode+",
        "$q MacRISC2$q encode-string encode+",
        "$q Power Macintosh$q encode-string encode+",
        "$q compatible$q property device-end"
    )
    return (($parts -join ' ') + ' ')
}

function Parse-RunOpts([string[]]$A) {
    $o = @{
        Disk = $DiskDefault; Ram = '1024'; Vram = '128'; Res = '1024x768'; Rom = ''; Cd = ''
        CpuMhz = $(if ($env:PPCOSX_CPU_MHZ) { $env:PPCOSX_CPU_MHZ } else { [string]$CpuMhzDefault })
        Model = $(if ($env:PPCOSX_MODEL) { $env:PPCOSX_MODEL } else { $ModelDefault })
        ModelSet = [bool]$env:PPCOSX_MODEL
        Card = $(if ($env:PPCOSX_CARD) { $env:PPCOSX_CARD } else { '9700' })
        Verbose = $false; Snapshot = $false; SshPort = ''; Monitor = $false; Trace = $false; Mode = 'radeon'
        NoAudio = ($env:PPCOSX_NO_AUDIO -eq '1'); Gpu = $(if ($env:PPCOSX_GPU) { $env:PPCOSX_GPU } else { 'vulkan' })
        Display = 'auto'; VkDevice = ''; VkDebug = ($env:PPCOSX_VK_DEBUG -eq '1'); Extra = @()
    }
    if (Test-Path $RomDefault) { $o.Rom = $RomDefault }
    $i = 0
    while ($i -lt $A.Count) {
        $k = $A[$i]; $i++
        $inline = $null
        if ($k -match '^(--[A-Za-z-]+)=(.*)$') { $k = $Matches[1]; $inline = $Matches[2] }
        $val = {
            param($name)
            if ($null -ne $inline) { return $inline }
            if ($i -ge $A.Count) { Die "$name needs a value" }
            $v = $A[$i]; $script:__adv = 1; return $v
        }
        $script:__adv = 0
        switch ($k) {
            '--disk'    { $o.Disk = Abs (& $val $k) }
            '--ram'     { $o.Ram = & $val $k }
            '--cpu-mhz' { $o.CpuMhz = & $val $k }
            '--model'   { $o.Model = & $val $k; $o.ModelSet = $true }
            '--vram'    { $o.Vram = & $val $k }
            '--res'     { $o.Res = & $val $k }
            '--rom'     { $o.Rom = Abs (& $val $k) }
            '--no-rom'  { $o.Rom = '' }
            { $_ -in '--attach-dvd', '--dvd', '--cd' } { $o.Cd = Abs (& $val $k) }
            '--vga'     { $o.Mode = 'vga' }
            '--card'    { $o.Card = & $val $k }
            '--jaguar'  { $o.Card = '9000' }
            '--gpu'     { $o.Gpu = & $val $k }
            '--gpuvulkan' { $o.Gpu = 'vulkan' }
            '--gpumetal'  { $o.Gpu = 'metal' }
            '--display' { $o.Display = & $val $k }
            '--vk-device' { $o.VkDevice = & $val $k }
            '--vk-debug'  { $o.VkDebug = $true }
            { $_ -in '--verbose', '-v' } { $o.Verbose = $true }
            '--snapshot' { $o.Snapshot = $true }
            '--no-audio' { $o.NoAudio = $true }
            '--ssh-port' { $o.SshPort = & $val $k }
            '--monitor'  { $o.Monitor = $true }
            '--trace-gpu' { $o.Trace = $true }
            '--dry-run'  { $script:DryRun = $true }
            '--console-log' { $script:ConsoleLog = $true }
            '--'         { if ($i -lt $A.Count) { $o.Extra = @($A[$i..($A.Count - 1)]) }; $i = $A.Count }
            { $_ -in '-h', '--help' } { Show-Usage; exit 0 }
            default { Die "unknown option: $k (see $Prog help)" }
        }
        $i += $script:__adv
    }
    if ($o.Card -eq '9000' -and -not $o.ModelSet) { $o.Model = 'default' }
    if ($o.Ram -notmatch '^\d+$') { Die '--ram takes a number of MB' }
    if ([int]$o.Ram -lt 256 -or [int]$o.Ram -gt 2048) { Die '--ram must be 256-2048 (mac99 limit is 2 GB)' }
    if ($o.Vram -notin '64', '128', '256') { Die '--vram must be 64, 128 or 256' }
    if ($o.CpuMhz -notmatch '^\d+$') { Die '--cpu-mhz takes a number of MHz' }
    if ($o.Model -in 'default', 'none', '') { $o.Model = '' }
    elseif ($o.Model -notmatch '^[A-Za-z0-9,._-]+$') { Die '--model takes a Mac model name like PowerBook5,8' }
    if ([int]$o.CpuMhz -lt 100 -or [int]$o.CpuMhz -gt 4000) { Die '--cpu-mhz must be 100-4000' }
    if ($o.Res -notmatch '^\d+x\d+$') { Die '--res looks like 1024x768' }
    if ($o.Card -notin '9700', '9000') { Die '--card takes 9700 (Tiger/Leopard) or 9000 (Jaguar)' }
    if ($o.Gpu -eq 'metal') { Die 'Metal is macOS only; on Windows the 3D renderer is Vulkan (--gpu vulkan)' }
    if ($o.Gpu -notin 'vulkan', 'software') { Die '--gpu takes vulkan (default) or software (diagnostic: no host 3D)' }
    if ($o.Display -notin 'auto', 'sdl', 'gtk') { Die '--display takes auto, sdl or gtk' }
    if ($o.VkDevice -and $o.VkDevice -notmatch '^\d+$') { Die '--vk-device takes a Vulkan device number (0, 1, ...)' }
    if ($o.Cd -and -not (Test-Path $o.Cd)) { Die "no such DVD image: $($o.Cd)" }
    if ($o.Rom) {
        if (-not (Test-Path $o.Rom)) { Die "no such ROM: $($o.Rom)" }
        try { [void](Rom-Check $o.Rom) } catch { Die "$($o.Rom): $($_.Exception.Message)" }
    }
    return $o
}

# Shared by run and install.  Returns the argument list.
function Build-Common([hashtable]$o, [string]$disk, [bool]$fromCd) {
    # Display: SDL is what the Windows build ships; GTK works if you built it in.
    $disp = $o.Display
    if ($disp -eq 'auto') {
        $h = Qemu-Probe 'display' @('-display', 'help')
        if ($h -match '(?m)^\s*sdl\s*$') { $disp = 'sdl' } elseif ($h -match '(?m)^\s*gtk\s*$') { $disp = 'gtk' } else { $disp = 'sdl' }
    }
    $hostUi = if ($disp -eq 'gtk') { @('-display', 'gtk,zoom-to-fit=on') } else { @('-display', 'sdl') }
    $audio = 'none'
    if (-not $o.NoAudio) {
        $h = Qemu-Probe 'audio' @('-audiodev', 'help')
        if ($h -match '\bdsound\b') { $audio = 'dsound' } elseif ($h -match '\bsdl\b') { $audio = 'sdl' }
        else { Warn 'no usable audio backend in this QEMU; sound is off' }
    }
    $hostUi += @('-audio', $audio)

    $machine = 'mac99,via=pmu'
    if ((Qemu-Probe 'machine' @('-machine', 'mac99,help')) -match 'cpu-mhz') { $machine += ",cpu-mhz=$($o.CpuMhz)" }
    else { Warn "this QEMU build can't set the CPU speed; run: $Prog update" }

    $accel = 'tcg'
    if ($env:PPCOSX_TB_SIZE) { $accel = "tcg,tb-size=$($env:PPCOSX_TB_SIZE)" }
    $hdboot = if ($fromCd) { '' } else { ',bootindex=0' }
    $q = @('-nodefaults', '-vga', 'none', '-machine', $machine, '-accel', $accel,
           '-smp', 'cpus=1,sockets=1,cores=1,threads=1', '-m', $o.Ram) + $hostUi +
         @('-drive', ('if=none,media=disk,id=hd,file.filename=' + (Esc-Opt $disk) + ',discard=unmap,detect-zeroes=unmap,l2-cache-size=64M,cache-clean-interval=0'),
           '-device', "ide-hd,bus=ide.0,unit=0,drive=hd$hdboot")
    if ($o.Snapshot) { $q += '-snapshot' }
    if ($o.Monitor) {
        if (-not ((Port-Free 4444) -and (Port-Free 4445))) { Die 'port 4444 or 4445 is in use (another VM running?)' }
        $q += @('-monitor', 'tcp:127.0.0.1:4444,server,nowait', '-qmp', 'tcp:127.0.0.1:4445,server,nowait')
    }
    return $q
}

function Add-Net([hashtable]$o, [string[]]$q) {
    $net = 'user,id=net0,ipv6=off'
    if ($o.SshPort) {
        if ($o.SshPort -notmatch '^\d+$') { Die '--ssh-port takes a port number' }
        if (-not (Port-Free ([int]$o.SshPort))) { Die "port $($o.SshPort) is in use" }
        $net += ",hostfwd=tcp:127.0.0.1:$($o.SshPort)-:22"
    }
    return ($q + @('-netdev', $net, '-device', 'sungem,netdev=net0'))
}

# Disks the GUI made (vm\<name>.qcow2) or lists in profiles.json; used when vm\macosx.qcow2 is absent.
function Find-Disks {
    $found = @(); $seen = @{}
    foreach ($f in @(Get-ChildItem -Path $VmDir -Filter '*.qcow2' -File -ErrorAction SilentlyContinue)) { $found += $f.FullName }
    $pj = P $VmDir 'profiles.json'
    if (Test-Path $pj) {
        try {
            $arr = Get-Content -Path $pj -Raw | ConvertFrom-Json
            foreach ($pr in @($arr)) {
                $dp = $pr.PSObject.Properties['Disk']
                if ($dp -and $dp.Value -and (Test-Path ([string]$dp.Value))) { $found += [string]$dp.Value }
            }
        } catch { }
    }
    $res = @()
    foreach ($d in $found) { $k = $d.ToLower(); if (-not $seen.ContainsKey($k)) { $seen[$k] = 1; $res += $d } }
    return $res
}

function Cmd-Run([string[]]$A) {
    $o = Parse-RunOpts $A
    Need-Qemu
    if (-not (Test-Path $o.Disk) -and ($o.Disk -eq $DiskDefault)) {
        $cand = @(Find-Disks)
        if ($cand.Count -eq 1) { Say "$(Rel $DiskDefault) does not exist; using the disk $(Rel $cand[0])"; $o.Disk = $cand[0] }
        elseif ($cand.Count -gt 1) {
            Die ("no disk at $(Rel $DiskDefault), but there are several others. Pick one with --disk:`n    " + ((@($cand | ForEach-Object { "$Prog --disk `"$(Rel $_)`"" })) -join "`n    "))
        }
    }
    if (-not (Test-Path $o.Disk)) {
        Die "no disk at $(Rel $o.Disk)`n    Install Mac OS X first:  $Prog install <tiger.iso>`n    or bring a disk:         $Prog import <disk.vmdk|.qcow2|.utm>"
    }
    if (Disk-InUse $o.Disk) { Die "a VM is already running on $(Split-Path $o.Disk -Leaf); shut it down first" }

    $q = Build-Common $o $o.Disk $false
    if ($o.Verbose) { $q += @('-prom-env', 'boot-args=-v') }
    $q += @('-usb', '-device', 'usb-mouse,bus=usb-bus.0', '-device', 'usb-kbd,bus=usb-bus.0')
    if ($o.Cd) {
        $dvd = Resolve-Dvd $o.Cd
        $q += @('-drive', ('if=none,media=cdrom,id=cd,readonly=on,file=' + (Esc-Opt $dvd)), '-device', 'ide-cd,bus=ide.0,unit=1,drive=cd')
    }
    $envVars = @{}
    if ($o.Mode -eq 'vga') {
        $q = @('-L', $FwVga, '-L', $QemuData) + $q +
             @('-device', ('loader,addr=0x4000000,file=' + (Esc-Opt (P $FwVga 'ppc-ndrvloader'))),
               '-prom-env', ('boot-command=' + (Get-ModelForth $o.Model) + 'init-program go'),
               '-device', 'VGA,edid=on', '-g', "$($o.Res)x32",
               '-device', 'ich9-usb-ehci1,id=usb-controller-0',
               '-device', 'ich9-usb-uhci1,masterbus=usb-controller-0.0,firstport=0,multifunction=on',
               '-device', 'ich9-usb-uhci2,masterbus=usb-controller-0.0,firstport=2,multifunction=on',
               '-device', 'ich9-usb-uhci3,masterbus=usb-controller-0.0,firstport=4,multifunction=on',
               '-device', 'virtio-tablet-pci',
               '-device', 'usb-tablet,bus=usb-bus.0')
        Say "Booting $(Rel $o.Disk) with the plain VGA framebuffer (no 3D)"
    } else {
        $q4 = '"'
        $vramHex = '{0:x}' -f ([int64]$o.Vram * 1048576)
        $boot = (Get-ModelForth $o.Model) + "$q4 /pci@f2000000/QEMU,VGA@$RadeonSlot$q4 ['] find-device catch 0= if"
        $boot += " h# $vramHex encode-int $q4 VRAM,totalsize$q4 property"
        if ($o.Card -eq '9700') {
            $boot += " $q4 ATY,R300$q4 encode-string $q4 model$q4 property"
            $boot += " $q4 113-A06500-124$q4 encode-string $q4 ATY,Rom#$q4 property"
            $boot += " $q4 109-A06501-00$q4 encode-string $q4 ATY,Card#$q4 property"
            $boot += " $q4 1.88$q4 encode-string $q4 ATY,Fcode$q4 property"
        }
        $boot += ' device-end then init-program go'

        $dev = "ati-radeon-$($o.Card),addr=$RadeonSlot.0,vgamem_mb=$($o.Vram)"
        if ($o.Gpu -eq 'vulkan') { $dev += ',renderer=vulkan' }
        if ($o.Card -eq '9000') {
            Warn "--jaguar: this project only implements the Radeon 9000's 3D engine (R200) for Apple's Metal, so on Windows Jaguar gets the slow software renderer. Tiger/Leopard (the default) use your GPU through Vulkan. $Prog --vga is the safe mode."
            $dev = "ati-radeon-$($o.Card),addr=$RadeonSlot.0,vgamem_mb=$($o.Vram)"
        }
        if ($o.Rom) { $dev += ',romfile=' + (Esc-Opt $o.Rom) + ',biosrom=' + (Esc-Opt $o.Rom) } else { $dev += ',romfile=' }
        $fwBios = if ($o.Card -eq '9000') { $FwJaguar } else { $FwRadeon }
        $envVars['QEMU_PPC_NDRV'] = (P $FwRadeon 'qemu_vga_hwc.ndrv')
        if ($o.VkDevice) { $envVars['PPCGPU_VK_DEVICE'] = $o.VkDevice }
        $envVars['VK_LOADER_LAYERS_DISABLE'] = '~implicit~'
        if ($o.VkDebug) { $envVars['VK_LOADER_DEBUG'] = 'error,warn' }
        $q = @('-L', $fwBios, '-L', $QemuData) + $q +
             @('-device', ('loader,addr=0x4000000,file=' + (Esc-Opt (P $FwRadeon 'ppc-ndrvloader'))),
               '-prom-env', "boot-command=$boot",
               '-global', 'uni-north-pci.agp-capable=on',
               '-device', $dev, '-g', "$($o.Res)x32",
               '-D', (P $VmDir 'gpu-trace.log'))
        # Jaguar's USB HID driver wants a relative mouse only.
        if ($o.Card -ne '9000') { $q += @('-device', 'usb-tablet,bus=usb-bus.0') }
        if ($o.Trace) { $q += @('-trace', 'ppc_mac_gpu_*') } else { $q += @('-trace', 'ppc_mac_gpu_realize') }
        $romNote = if ($o.Rom) { ", ROM $(Split-Path $o.Rom -Leaf)" } else { '' }
        Say "Booting $(Rel $o.Disk) with the ATI Radeon $($o.Card) PRO ($($o.Vram) MB, $($o.Gpu)$romNote)"
    }
    $q = Add-Net $o $q
    Hint 'Release the mouse: Ctrl+Alt+G.  Quit: shut down Mac OS X, or close the QEMU window.'
    if ($o.Snapshot) { Hint '--snapshot: nothing you do in this session is saved to the disk.' }

    New-Item -ItemType Directory -Force -Path $VmDir | Out-Null
    $rc = Start-Qemu ($q + $o.Extra) $envVars
    if ($rc -ne 0) { Warn "QEMU exited with code $rc (see docs\WINDOWS.md, 'Troubleshooting')." }
    exit $rc
}

# --------------------------------------------------------------- install ---
function Cmd-Install([string[]]$A) {
    Need-Qemu
    $iso = ''; $size = '40G'; $pass = @()
    for ($i = 0; $i -lt $A.Count; $i++) {
        switch -Regex ($A[$i]) {
            '^--size$' { $i++; $size = $A[$i]; break }
            '^--(disk|ram|res|cpu-mhz)$' { $pass += $A[$i]; $i++; $pass += $A[$i]; break }
            '^(--verbose|-v|--monitor|--dry-run|--console-log|--display)$' { $pass += $A[$i]; if ($A[$i] -eq '--display') { $i++; $pass += $A[$i] }; break }
            '^-' { Die "unknown option $($A[$i])" }
            default { $iso = Abs $A[$i] }
        }
    }
    if (-not $iso) { Die "usage: $Prog install <Mac OS X install DVD: .iso .cdr .dmg .toast> [--size 40G]" }
    if (-not (Test-Path $iso)) { Die "no such file: $iso" }
    $iso = Resolve-Dvd $iso
    $o = Parse-RunOpts $pass
    if (-not (Test-Path $o.Disk)) { New-DiskFile $size $o.Disk } else { Warn "installing onto the existing disk $(Rel $o.Disk)" }

    # Plain OpenBIOS CD boot with the QEMU VGA: what the Tiger installer is known to work with.
    # -no-reboot turns the installer's final restart into a clean exit.
    $q = Build-Common $o $o.Disk $true
    $q = @('-L', $FwVga, '-L', $QemuData) + $q +
         @('-device', 'VGA,edid=on', '-g', "$($o.Res)x32",
           '-drive', ('if=none,media=cdrom,id=cd,readonly=on,file=' + (Esc-Opt $iso)),
           '-device', 'ide-cd,bus=ide.1,unit=0,drive=cd,bootindex=0',
           '-boot', 'd', '-no-reboot',
           '-usb', '-device', 'usb-mouse,bus=usb-bus.0', '-device', 'usb-kbd,bus=usb-bus.0',
           '-device', 'usb-tablet,bus=usb-bus.0')
    if ($o.Verbose) { $q += @('-prom-env', 'boot-args=-v') }
    $q = Add-Net $o $q
    @"

Installing Mac OS X from $(Split-Path $iso -Leaf) onto $(Rel $o.Disk)

  1. Pick a language. When the installer opens, choose Utilities > Disk Utility.
  2. Select the QEMU hard disk, Erase it as "Mac OS Extended (Journaled)",
     then quit Disk Utility.
  3. Continue the installer and pick the new volume. The install takes
     roughly 30-60 minutes; "Customize" and unticking printer drivers and
     extra languages makes it much faster.
  4. When it restarts, this window closes. Then boot it with:  $Prog run

"@ | Write-Host
    $rc = Start-Qemu $q @{}
    exit $rc
}

# ------------------------------------------------------------------ diag ---
# Collects everything needed to debug a boot problem into vm\diag.txt.
function Cmd-Diag {
    New-Item -ItemType Directory -Force -Path $VmDir | Out-Null
    $out = P $VmDir 'diag.txt'
    $L = New-Object System.Collections.Generic.List[string]
    $L.Add("ppcosx diag  $(Get-Date -Format s)")
    $os = Get-CimInstance Win32_OperatingSystem -ErrorAction SilentlyContinue
    if ($os) { $L.Add("$($os.Caption) build $($os.BuildNumber)") }
    foreach ($g in @(Get-CimInstance Win32_VideoController -ErrorAction SilentlyContinue)) { $L.Add("GPU: $($g.Name) driver $($g.DriverVersion)") }
    if (Test-Path $Qemu) { $L.Add((((Invoke-Capture $Qemu @('--version') 15000).Text) -split "`r?`n")[0]) } else { $L.Add('QEMU not built') }
    $L.Add(''); $L.Add('--- files in vm\ ---')
    foreach ($f in @(Get-ChildItem -Path $VmDir -File -ErrorAction SilentlyContinue)) { $L.Add(('{0}  {1}  {2}' -f $f.Name, (Human-Size $f.Length), $f.LastWriteTime)) }
    $pj = P $VmDir 'profiles.json'
    if (Test-Path $pj) { $L.Add(''); $L.Add('--- profiles.json ---'); $L.Add((Get-Content -Path $pj -Raw)) }
    $ql = P $VmDir 'qemu.log'
    $L.Add(''); $L.Add('--- vm\qemu.log: distinct lines that are not "T3 ..." GPU packet dumps (max 250) ---')
    if (Test-Path $ql) {
        $seenL = @{}; $ops = @{}; $kept = 0; $total = 0
        foreach ($x in [System.IO.File]::ReadLines($ql)) {
            $total++
            if ($x.StartsWith('T3 ')) { $op = $x.Split(' ')[1]; if ($ops.ContainsKey($op)) { $ops[$op]++ } else { $ops[$op] = 1 }; continue }
            if ($kept -ge 250 -or $seenL.ContainsKey($x)) { continue }
            $seenL[$x] = 1; $kept++
            $L.Add($x.Substring(0, [math]::Min($x.Length, 400)))
        }
        $L.Add(''); $L.Add("qemu.log has $total lines. GPU packet dumps by opcode:")
        foreach ($k in ($ops.Keys | Sort-Object)) { $L.Add("  T3 opcode $k : $($ops[$k])") }
    } else { $L.Add('(no qemu.log yet: start the VM once first)') }
    $gl = P $VmDir 'gpu-trace.log'
    $L.Add(''); $L.Add('--- vm\gpu-trace.log summary ---')
    if (Test-Path $gl) {
        $n = 0; $mf = 0.0; $mp = 0.0; $md = 0.0; $mfl = 0.0; $other = 0
        foreach ($x in [System.IO.File]::ReadLines($gl)) {
            if ($x -match '^ppc-mac-gpu rate: ([\d.]+) flips/s, ([\d.]+) present-ops/s, (\d+) draws/s.*?, (\d+) flushes/s') {
                $n++
                if ([double]$Matches[1] -gt $mf) { $mf = [double]$Matches[1] }
                if ([double]$Matches[2] -gt $mp) { $mp = [double]$Matches[2] }
                if ([double]$Matches[3] -gt $md) { $md = [double]$Matches[3] }
                if ([double]$Matches[4] -gt $mfl) { $mfl = [double]$Matches[4] }
            } elseif (-not ($x -match '^ppc-mac-gpu (ring|scanout):')) {
                if ($other -lt 60) { $L.Add($x.Substring(0, [math]::Min($x.Length, 400))); $other++ }
            }
        }
        $L.Add("rate lines: $n   max flips/s: $mf   max present-ops/s: $mp   max draws/s: $md   max flushes/s: $mfl")
    } else { $L.Add('(none)') }
    $L.Add(''); $L.Add('--- vm\qemu.log (last 8 lines) ---')
    if (Test-Path $ql) { foreach ($x in @(Get-Content -Path $ql -Tail 8 -ErrorAction SilentlyContinue)) { $L.Add($x) } }
    [System.IO.File]::WriteAllLines($out, $L.ToArray())
    Ok "wrote $(Rel $out)  - attach that file when asking for help"
}

# ------------------------------------------------------- link / update ---
function Cmd-Gui {
    $g = P $Repo 'ppcosx-gui.exe'
    if (-not (Test-Path $g)) { Die "ppcosx-gui.exe is not built. Run:  powershell -ExecutionPolicy Bypass -File .\build-windows.ps1 -GuiOnly" }
    Start-Process -FilePath $g -WorkingDirectory $Repo
}
function Cmd-Link {
    $cur = [Environment]::GetEnvironmentVariable('Path', 'User')
    if (-not $cur) { $cur = '' }
    $parts = @($cur -split ';' | Where-Object { $_ })
    if ($parts -contains $Repo) { Ok "$Repo is already on your PATH"; return }
    [Environment]::SetEnvironmentVariable('Path', (($parts + $Repo) -join ';'), 'User')
    Ok "added $Repo to your user PATH"
    Hint "Open a new terminal, then use  ppcosx  (ppcosx.cmd) from anywhere."
}
function Cmd-Unlink {
    $cur = [Environment]::GetEnvironmentVariable('Path', 'User')
    $parts = @($cur -split ';' | Where-Object { $_ -and $_ -ne $Repo })
    [Environment]::SetEnvironmentVariable('Path', ($parts -join ';'), 'User')
    Ok "removed $Repo from your user PATH"
    Hint "Your VMs are untouched in $VmDir."
}
function Cmd-Update([string[]]$A) {
    if (-not (Test-Path (P $Repo '.git'))) { Die "$Repo is not a git checkout; clone it again with git" }
    if (-not (Get-Command git -ErrorAction SilentlyContinue)) { Die 'git is not on your PATH; run "git pull" yourself, then: ' + "$Prog setup" }
    Say "Updating $Repo"
    & git -C $Repo pull --ff-only
    if ($LASTEXITCODE -ne 0) { Die 'git pull failed (local changes?)' }
    Cmd-Setup $A
}

# ------------------------------------------------------------------ main ---
$script:DryRun = ($env:PPCOSX_DRYRUN -eq '1')
$script:ConsoleLog = ($env:PPCOSX_CONSOLE_LOG -eq '1')
if ($ScriptArgs.Count -eq 0) {
    if ((Test-Path $Qemu) -and (Test-Path $DiskDefault)) { $ScriptArgs = @('run') } else { $ScriptArgs = @('help') }
}
$cmd = $ScriptArgs[0]
if ($cmd.StartsWith('-') -and $cmd -notin '-h', '--help') { $ScriptArgs = @('run') + $ScriptArgs; $cmd = 'run' }
$rest = @(if ($ScriptArgs.Count -gt 1) { $ScriptArgs[1..($ScriptArgs.Count - 1)] })

switch ($cmd) {
    'setup'                      { Cmd-Setup $rest }
    { $_ -in 'doctor', 'check' } { Cmd-Doctor $rest }
    { $_ -in 'run', 'start', 'boot' } { Cmd-Run $rest }
    'install'                    { Cmd-Install $rest }
    'import'                     { Cmd-Import $rest }
    'rom'                        { Cmd-Rom $rest }
    'new-disk'                   { Cmd-NewDisk $rest }
    { $_ -in 'snapshot', 'snap' } { Cmd-Snapshot $rest }
    { $_ -in 'update', 'upgrade' } { Cmd-Update $rest }
    'diag'                       { Cmd-Diag }
    'gui'                        { Cmd-Gui }
    'link'                       { Cmd-Link }
    'unlink'                     { Cmd-Unlink }
    { $_ -in 'help', '-h', '--help' } { Show-Usage }
    default { Write-Host "unknown command: $cmd`n" -ForegroundColor Red; Show-Usage; exit 2 }
}
