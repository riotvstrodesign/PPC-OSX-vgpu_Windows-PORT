@echo off
rem Double-click me to build qemu-system-ppc.exe. Everything is also saved in build-windows.log
cd /d "%~dp0"
findstr /C:"ScriptVersion = 'v8'" "%~dp0build-windows.ps1" >nul 2>&1
if errorlevel 1 (
  echo.
  echo  The build-windows.ps1 in this folder is an OLD version, so it was not run.
  echo  Unzip the zip into this folder again and, when Windows asks about files that
  echo  already exist, choose "Replace the files in the destination".
  echo.
  pause
  exit /b 1
)
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0build-windows.ps1" -NoPause
echo.
echo ---- finished, exit code %ERRORLEVEL%. If something failed, read build-windows.log ----
pause
