// PpcOsxGui.cs - Windows front-end for ppcosxkvm.
//
// A thin GUI: it stores VM profiles, turns them into command-line options and
// runs ppcosx.ps1 (which does the real work), showing the output live.
//
// C# 5 / .NET Framework 4.x on purpose: it compiles with the csc.exe that
// ships with Windows (no SDK needed). See build-windows.ps1 -GuiOnly.
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Runtime.InteropServices;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;
using System.Web.Script.Serialization;
using System.Windows.Forms;

namespace PpcOsx
{
    // ------------------------------------------------------------------ model
    public class VmProfile
    {
        public string Name { get; set; }
        public string Disk { get; set; }
        public int Ram { get; set; }
        public int Vram { get; set; }
        public string Res { get; set; }
        public string Card { get; set; }        // "9700" | "vga" | "9000"
        public string Model { get; set; }
        public int CpuMhz { get; set; }
        public string Rom { get; set; }
        public bool NoRom { get; set; }
        public string Dvd { get; set; }
        public string Display { get; set; }     // auto | sdl | gtk
        public string VkDevice { get; set; }    // "" = automatic
        public bool Verbose { get; set; }
        public bool Snapshot { get; set; }
        public bool NoAudio { get; set; }
        public bool Monitor { get; set; }
        public bool TraceGpu { get; set; }
        public string SshPort { get; set; }
        public string Extra { get; set; }

        public VmProfile()
        {
            Name = "Mac OS X"; Disk = ""; Ram = 1024; Vram = 128; Res = "1024x768"; Card = "9700";
            Model = "PowerBook5,8"; CpuMhz = 2000; Rom = ""; Dvd = ""; Display = "auto"; VkDevice = "";
            SshPort = ""; Extra = "";
        }
    }

    // ---------------------------------------------------------------- helpers
    static class Env
    {
        public static string Root;
        public static string VmDir;
        public static string ProfilesFile { get { return Path.Combine(VmDir, "profiles.json"); } }
        public static string Script(string name) { return Path.Combine(Root, name); }
        public static bool IsWindows { get { return Environment.OSVersion.Platform == PlatformID.Win32NT; } }

        public static string QemuExe
        {
            get
            {
                string e = Environment.GetEnvironmentVariable("PPCOSX_QEMU");
                if (!string.IsNullOrEmpty(e)) return e;
                return Path.Combine(Path.Combine(Root, "win-qemu"), IsWindows ? "qemu-system-ppc.exe" : "qemu-system-ppc");
            }
        }
        public static bool QemuBuilt { get { return File.Exists(QemuExe); } }

        public static string PowerShell
        {
            get
            {
                string e = Environment.GetEnvironmentVariable("PPCOSX_POWERSHELL");
                return string.IsNullOrEmpty(e) ? "powershell.exe" : e;
            }
        }

        public static bool Init()
        {
            string start = Environment.GetEnvironmentVariable("PPCOSX_ROOT");
            if (string.IsNullOrEmpty(start)) start = AppDomain.CurrentDomain.BaseDirectory;
            DirectoryInfo d = new DirectoryInfo(start);
            while (d != null)
            {
                if (File.Exists(Path.Combine(d.FullName, "ppcosx.ps1"))) { Root = d.FullName; break; }
                d = d.Parent;
            }
            if (Root == null) return false;
            string vm = Environment.GetEnvironmentVariable("PPCOSX_VM_DIR");
            VmDir = string.IsNullOrEmpty(vm) ? Path.Combine(Root, "vm") : vm;
            return true;
        }
    }

    static class Args
    {
        // Quote one argument for a Windows command line (CommandLineToArgvW rules).
        public static string Quote(string a)
        {
            if (a.Length > 0 && a.IndexOfAny(new char[] { ' ', '\t', '"', '\n' }) < 0) return a;
            StringBuilder sb = new StringBuilder("\"");
            int bs = 0;
            foreach (char c in a)
            {
                if (c == '\\') bs++;
                else if (c == '"') { sb.Append('\\', bs * 2 + 1); sb.Append('"'); bs = 0; }
                else { if (bs > 0) { sb.Append('\\', bs); bs = 0; } sb.Append(c); }
            }
            if (bs > 0) sb.Append('\\', bs * 2);
            sb.Append('"');
            return sb.ToString();
        }

        public static string Join(IList<string> args)
        {
            List<string> q = new List<string>();
            foreach (string a in args) q.Add(Quote(a));
            return string.Join(" ", q.ToArray());
        }

        // Split a user-typed "extra args" line (double quotes group words).
        public static List<string> Split(string s)
        {
            List<string> r = new List<string>();
            if (string.IsNullOrEmpty(s)) return r;
            StringBuilder cur = new StringBuilder();
            bool inQ = false, any = false;
            foreach (char c in s)
            {
                if (c == '"') { inQ = !inQ; any = true; }
                else if (char.IsWhiteSpace(c) && !inQ) { if (any || cur.Length > 0) { r.Add(cur.ToString()); cur.Length = 0; any = false; } }
                else cur.Append(c);
            }
            if (any || cur.Length > 0) r.Add(cur.ToString());
            return r;
        }

        // VM profile -> ppcosx.ps1 "run" options.
        public static List<string> ForRun(VmProfile p)
        {
            List<string> a = new List<string>();
            a.Add("run");
            if (!string.IsNullOrEmpty(p.Disk)) { a.Add("--disk"); a.Add(p.Disk); }
            a.Add("--ram"); a.Add(p.Ram.ToString());
            a.Add("--res"); a.Add(p.Res);
            a.Add("--cpu-mhz"); a.Add(p.CpuMhz.ToString());
            a.Add("--model"); a.Add(string.IsNullOrEmpty(p.Model) ? "default" : p.Model);
            if (p.Card == "vga") a.Add("--vga");
            else
            {
                a.Add("--vram"); a.Add(p.Vram.ToString());
                if (p.Card == "9000") a.Add("--jaguar");
                if (!string.IsNullOrEmpty(p.VkDevice)) { a.Add("--vk-device"); a.Add(p.VkDevice); }
            }
            if (p.NoRom) a.Add("--no-rom");
            else if (!string.IsNullOrEmpty(p.Rom)) { a.Add("--rom"); a.Add(p.Rom); }
            if (!string.IsNullOrEmpty(p.Dvd)) { a.Add("--attach-dvd"); a.Add(p.Dvd); }
            if (p.Display != "auto" && !string.IsNullOrEmpty(p.Display)) { a.Add("--display"); a.Add(p.Display); }
            if (p.Verbose) a.Add("--verbose");
            if (p.Snapshot) a.Add("--snapshot");
            if (p.NoAudio) a.Add("--no-audio");
            if (!string.IsNullOrEmpty(p.SshPort)) { a.Add("--ssh-port"); a.Add(p.SshPort); }
            if (p.Monitor) a.Add("--monitor");
            if (p.TraceGpu && p.Card != "vga") a.Add("--trace-gpu");
            List<string> extra = Split(p.Extra);
            if (extra.Count > 0) { a.Add("--"); a.AddRange(extra); }
            return a;
        }
    }

    // ------------------------------------------------------------- processes
    class Job
    {
        Process proc;
        public Action<string> OnLine;
        public Action<int> OnExit;
        public bool Running { get; private set; }
        static readonly Regex Ansi = new Regex("\x1b\\[[0-9;?]*[A-Za-z]", RegexOptions.Compiled);

        public static string PsArgs(string script, IList<string> args)
        {
            List<string> all = new List<string>();
            all.Add("-NoProfile"); all.Add("-ExecutionPolicy"); all.Add("Bypass"); all.Add("-File"); all.Add(Env.Script(script));
            all.AddRange(args);
            return Args.Join(all);
        }

        public void Start(string script, IList<string> args)
        {
            ProcessStartInfo psi = new ProcessStartInfo(Env.PowerShell, PsArgs(script, args));
            psi.UseShellExecute = false;
            psi.RedirectStandardOutput = true;
            psi.RedirectStandardError = true;
            psi.CreateNoWindow = true;
            psi.WorkingDirectory = Env.Root;
            proc = new Process();
            proc.StartInfo = psi;
            proc.EnableRaisingEvents = true;
            proc.OutputDataReceived += delegate(object s, DataReceivedEventArgs e) { Emit(e.Data); };
            proc.ErrorDataReceived += delegate(object s, DataReceivedEventArgs e) { Emit(e.Data); };
            proc.Exited += delegate(object s, EventArgs e)
            {
                int code = -1;
                try { proc.WaitForExit(); code = proc.ExitCode; } catch (Exception) { }
                Running = false;
                if (OnExit != null) OnExit(code);
            };
            Running = true;
            proc.Start();
            proc.BeginOutputReadLine();
            proc.BeginErrorReadLine();
        }

        void Emit(string line)
        {
            if (line == null || OnLine == null) return;
            OnLine(Ansi.Replace(line, ""));
        }

        public void Kill()
        {
            try
            {
                if (proc == null || proc.HasExited) return;
                if (Env.IsWindows)
                {
                    ProcessStartInfo k = new ProcessStartInfo("taskkill.exe", "/PID " + proc.Id + " /T /F");
                    k.CreateNoWindow = true; k.UseShellExecute = false;
                    Process.Start(k);
                }
                else proc.Kill();
            }
            catch (Exception) { }
        }
    }

    // --------------------------------------------------- Vulkan GPU enumeration
    // Lists the GPUs the Vulkan runtime reports, in the same order QEMU's renderer sees them
    // (we load the same libvulkan-1.dll that ships next to qemu-system-ppc.exe when it exists).
    static class VulkanProbe
    {
        [DllImport("kernel32.dll", CharSet = CharSet.Unicode, SetLastError = true)]
        static extern IntPtr LoadLibraryExW(string path, IntPtr file, uint flags);
        [DllImport("kernel32.dll", CharSet = CharSet.Ansi, ExactSpelling = true)]
        static extern IntPtr GetProcAddress(IntPtr module, string name);
        [DllImport("libdl.so.2")] static extern IntPtr dlopen(string file, int flags);
        [DllImport("libdl.so.2")] static extern IntPtr dlsym(IntPtr handle, string name);

        [StructLayout(LayoutKind.Sequential)]
        struct InstanceInfo
        {
            public int sType; public IntPtr pNext; public uint flags; public IntPtr pApp;
            public uint layerCount; public IntPtr layers; public uint extCount; public IntPtr exts;
        }
        [UnmanagedFunctionPointer(CallingConvention.StdCall)] delegate int CreateInstanceFn(ref InstanceInfo ci, IntPtr alloc, out IntPtr inst);
        [UnmanagedFunctionPointer(CallingConvention.StdCall)] delegate int EnumDevicesFn(IntPtr inst, ref uint count, IntPtr devs);
        [UnmanagedFunctionPointer(CallingConvention.StdCall)] delegate void GetPropsFn(IntPtr dev, IntPtr props);
        [UnmanagedFunctionPointer(CallingConvention.StdCall)] delegate void DestroyInstanceFn(IntPtr inst, IntPtr alloc);

        static IntPtr Load(string name)
        {
            if (Env.IsWindows)
            {
                bool full = Path.IsPathRooted(name);
                if (full && !File.Exists(name)) return IntPtr.Zero;
                return LoadLibraryExW(name, IntPtr.Zero, full ? 0x8u : 0u);   // 0x8 = search the DLL's own folder for its dependencies
            }
            return dlopen(name, 2);
        }

        static T Fn<T>(IntPtr lib, string name) where T : class
        {
            IntPtr p = Env.IsWindows ? GetProcAddress(lib, name) : dlsym(lib, name);
            if (p == IntPtr.Zero) throw new InvalidOperationException("missing " + name);
            return (T)(object)Marshal.GetDelegateForFunctionPointer(p, typeof(T));
        }

        // Returns one display string per GPU ("GPU 0: NVIDIA ... (discrete)"); note explains an empty list.
        public static List<string> Devices(out string note)
        {
            List<string> res = new List<string>();
            note = "";
            try
            {
                string[] cands = Env.IsWindows
                    ? new string[] { Path.Combine(Path.Combine(Env.Root, "win-qemu"), "libvulkan-1.dll"), "vulkan-1.dll" }
                    : new string[] { "libvulkan.so.1" };
                IntPtr lib = IntPtr.Zero;
                foreach (string c in cands) { lib = Load(c); if (lib != IntPtr.Zero) break; }
                if (lib == IntPtr.Zero) { note = "Vulkan runtime not found (update your GPU driver)"; return res; }

                CreateInstanceFn create = Fn<CreateInstanceFn>(lib, "vkCreateInstance");
                EnumDevicesFn enumDev = Fn<EnumDevicesFn>(lib, "vkEnumeratePhysicalDevices");
                GetPropsFn getProps = Fn<GetPropsFn>(lib, "vkGetPhysicalDeviceProperties");
                DestroyInstanceFn destroy = Fn<DestroyInstanceFn>(lib, "vkDestroyInstance");

                InstanceInfo ci = new InstanceInfo();
                ci.sType = 1;   // VK_STRUCTURE_TYPE_INSTANCE_CREATE_INFO
                IntPtr inst;
                int rc = create(ref ci, IntPtr.Zero, out inst);
                if (rc != 0) { note = "Vulkan could not start (error " + rc + ")"; return res; }
                try
                {
                    uint n = 0;
                    enumDev(inst, ref n, IntPtr.Zero);
                    if (n == 0) { note = "Vulkan reports no GPUs"; return res; }
                    IntPtr devs = Marshal.AllocHGlobal((int)n * IntPtr.Size);
                    IntPtr props = Marshal.AllocHGlobal(2048);
                    try
                    {
                        enumDev(inst, ref n, devs);
                        for (int i = 0; i < (int)n; i++)
                        {
                            IntPtr dev = Marshal.ReadIntPtr(devs, i * IntPtr.Size);
                            getProps(dev, props);
                            int type = Marshal.ReadInt32(props, 16);                    // VkPhysicalDeviceType
                            string name = Marshal.PtrToStringAnsi(IntPtr.Add(props, 20)); // deviceName[256]
                            string kind = type == 2 ? "discrete" : type == 1 ? "integrated" : type == 3 ? "virtual" : type == 4 ? "software" : "other";
                            res.Add("GPU " + i + ": " + name + " (" + kind + ")");
                        }
                    }
                    finally { Marshal.FreeHGlobal(devs); Marshal.FreeHGlobal(props); }
                }
                finally { destroy(inst, IntPtr.Zero); }
            }
            catch (Exception ex) { note = "Could not list GPUs: " + ex.Message; }
            return res;
        }
    }

    // ----------------------------------------------------------- small dialogs
    static class Dialogs
    {
        public static string Ask(IWin32Window owner, string title, string label, string def)
        {
            using (Form f = new Form())
            {
                f.Text = title; f.FormBorderStyle = FormBorderStyle.FixedDialog; f.StartPosition = FormStartPosition.CenterParent;
                f.MaximizeBox = false; f.MinimizeBox = false; f.ShowInTaskbar = false; f.ClientSize = new Size(380, 120);
                f.Font = new Font("Segoe UI", 9f);
                Label l = new Label(); l.Text = label; l.AutoSize = true; l.Location = new Point(14, 14);
                TextBox t = new TextBox(); t.Text = def; t.Location = new Point(16, 40); t.Width = 348;
                Button ok = new Button(); ok.Text = "OK"; ok.DialogResult = DialogResult.OK; ok.Location = new Point(208, 78); ok.Width = 74;
                Button cancel = new Button(); cancel.Text = "Cancel"; cancel.DialogResult = DialogResult.Cancel; cancel.Location = new Point(290, 78); cancel.Width = 74;
                f.Controls.AddRange(new Control[] { l, t, ok, cancel });
                f.AcceptButton = ok; f.CancelButton = cancel;
                if (f.ShowDialog(owner) != DialogResult.OK) return null;
                return t.Text.Trim();
            }
        }
    }

    class InstallDialog : Form
    {
        public TextBox VmName = new TextBox();
        public TextBox Iso = new TextBox();
        public NumericUpDown SizeGb = new NumericUpDown();
        public NumericUpDown Ram = new NumericUpDown();

        public InstallDialog()
        {
            Text = "Install Mac OS X"; FormBorderStyle = FormBorderStyle.FixedDialog; StartPosition = FormStartPosition.CenterParent;
            MaximizeBox = false; MinimizeBox = false; ShowInTaskbar = false; Font = new Font("Segoe UI", 9f);
            ClientSize = new Size(560, 372);

            Label intro = new Label();
            intro.Text = "Install Mac OS X Tiger (or Leopard) from a DVD image onto a new virtual disk.\r\nYou need your own install disc image (.iso, .cdr, .dmg or .toast).";
            intro.Location = new Point(16, 14); intro.Size = new Size(528, 36);

            Label l1 = new Label(); l1.Text = "Name"; l1.Location = new Point(16, 64); l1.AutoSize = true;
            VmName.Location = new Point(130, 60); VmName.Width = 414; VmName.Text = "Mac OS X Tiger";
            Label l2 = new Label(); l2.Text = "Install disc image"; l2.Location = new Point(16, 98); l2.AutoSize = true;
            Iso.Location = new Point(130, 94); Iso.Width = 330;
            Button browse = new Button(); browse.Text = "Browse..."; browse.Location = new Point(468, 92); browse.Width = 76;
            browse.Click += delegate
            {
                using (OpenFileDialog d = new OpenFileDialog())
                {
                    d.Filter = "DVD images (*.iso;*.cdr;*.dmg;*.toast)|*.iso;*.cdr;*.dmg;*.toast|All files (*.*)|*.*";
                    if (d.ShowDialog(this) == DialogResult.OK) Iso.Text = d.FileName;
                }
            };
            Label l3 = new Label(); l3.Text = "Disk size (GB)"; l3.Location = new Point(16, 132); l3.AutoSize = true;
            SizeGb.Location = new Point(130, 128); SizeGb.Minimum = 4; SizeGb.Maximum = 512; SizeGb.Value = 40; SizeGb.Width = 80;
            Label l4 = new Label(); l4.Text = "Memory (MB)"; l4.Location = new Point(250, 132); l4.AutoSize = true;
            Ram.Location = new Point(344, 128); Ram.Minimum = 256; Ram.Maximum = 2048; Ram.Increment = 128; Ram.Value = 1024; Ram.Width = 80;

            Label steps = new Label();
            steps.Text = "What happens next\r\n\r\n" +
                "1.  A QEMU window opens with the Mac OS X installer. Pick a language.\r\n" +
                "2.  Choose Utilities > Disk Utility, select the QEMU disk, erase it as\r\n" +
                "     \"Mac OS Extended (Journaled)\", then quit Disk Utility.\r\n" +
                "3.  Continue the installer and pick the new volume. It takes 30-60 minutes;\r\n" +
                "     \"Customize\" and unticking printer drivers and languages speeds it up.\r\n" +
                "4.  When it restarts, the window closes. Select the VM here and press Start.";
            steps.Location = new Point(16, 172); steps.Size = new Size(528, 148);
            steps.BackColor = Color.FromArgb(244, 245, 247); steps.Padding = new Padding(10);

            Button ok = new Button(); ok.Text = "Start installer"; ok.Location = new Point(404, 330); ok.Width = 140; ok.Height = 28;
            Button cancel = new Button(); cancel.Text = "Cancel"; cancel.DialogResult = DialogResult.Cancel; cancel.Location = new Point(320, 330); cancel.Width = 76; cancel.Height = 28;
            ok.Click += delegate
            {
                if (VmName.Text.Trim().Length == 0) { MessageBox.Show(this, "Give the virtual machine a name.", Text); return; }
                if (!File.Exists(Iso.Text)) { MessageBox.Show(this, "Choose the install disc image first.", Text); return; }
                DialogResult = DialogResult.OK;
            };
            Controls.AddRange(new Control[] { intro, l1, VmName, l2, Iso, browse, l3, SizeGb, l4, Ram, steps, ok, cancel });
            AcceptButton = ok; CancelButton = cancel;
        }
    }

    // -------------------------------------------------------------- main form
    class MainForm : Form
    {
        static readonly Color SideBg = Color.FromArgb(30, 32, 38);
        static readonly Color SideSel = Color.FromArgb(52, 57, 68);
        static readonly Color Accent = Color.FromArgb(46, 160, 67);
        static readonly Color Danger = Color.FromArgb(196, 58, 58);
        static readonly Color LogBg = Color.FromArgb(22, 24, 29);

        List<VmProfile> profiles = new List<VmProfile>();
        VmProfile cur;
        bool loading;
        Job job;
        string jobTitle = "";

        ListBox vmList = new ListBox();
        Panel header = new Panel();
        Label vmTitle = new Label();
        Label status = new Label();
        Button startBtn = new Button();
        Button stopBtn = new Button();
        Label banner = new Label();
        Panel welcome = new Panel();
        SplitContainer split = new SplitContainer();
        TabControl tabs = new TabControl();
        RichTextBox log = new RichTextBox();
        TextBox preview = new TextBox();
        Button checkBtn = new Button();
        Button buildBtn = new Button();

        // hardware
        TextBox nameBox = new TextBox();
        ComboBox cardBox = new ComboBox();
        Label cardHint = new Label();
        ComboBox vramBox = new ComboBox();
        ComboBox resBox = new ComboBox();
        NumericUpDown ramBox = new NumericUpDown();
        ComboBox modelBox = new ComboBox();
        NumericUpDown mhzBox = new NumericUpDown();
        ComboBox vkBox = new ComboBox();
        ComboBox dispBox = new ComboBox();
        CheckBox soundBox = new CheckBox();
        Label vkHint = new Label();
        // storage
        TextBox diskBox = new TextBox();
        Label diskInfo = new Label();
        TextBox dvdBox = new TextBox();
        TextBox romBox = new TextBox();
        CheckBox noRomBox = new CheckBox();
        CheckBox snapModeBox = new CheckBox();
        ListBox snapList = new ListBox();
        // advanced
        CheckBox verboseBox = new CheckBox();
        TextBox sshBox = new TextBox();
        CheckBox monitorBox = new CheckBox();
        CheckBox traceBox = new CheckBox();
        TextBox extraBox = new TextBox();

        static readonly string[] CardKeys = { "9700", "vga", "9000" };
        static readonly string[] CardNames = {
            "ATI Radeon 9700 PRO  -  hardware 3D through Vulkan (Tiger / Leopard)",
            "Plain VGA framebuffer  -  no 3D (safe mode)",
            "ATI Radeon 9000  -  Jaguar 10.2 (3D is software-only on Windows)" };
        static readonly string[] CardHints = {
            "Quartz Extreme, Core Image and OpenGL run on your GPU, translated to Vulkan.",
            "No acceleration at all. Use it if the Radeon mode gives a black screen.",
            "Jaguar's R200 3D engine only has a Metal renderer in this project, so on Windows it falls back to the slow software renderer." };

        public MainForm()
        {
            Text = "PowerPC Mac OS X  -  Radeon 9700 on Vulkan";
            Font = new Font("Segoe UI", 9f);
            ClientSize = new Size(1120, 780);
            MinimumSize = new Size(940, 640);
            StartPosition = FormStartPosition.CenterScreen;
            BuildMenu();
            BuildLayout();
            logTimer = new System.Windows.Forms.Timer(); logTimer.Interval = 120; logTimer.Tick += delegate { FlushLog(300); }; logTimer.Start();
            LoadProfiles();
            RefreshList();
            SetState();
            Shown += delegate
            {
                DetectGpus();   // needs the window handle, so not in the constructor
                if (cur != null) ProfileToUi();
                if (!Env.QemuBuilt) Log("QEMU is not built yet. Press \"Build / Update QEMU\" in the sidebar (first build takes 20-40 minutes).", Color.Khaki);
                else Log("Ready. Release the mouse inside the VM with Ctrl+Alt+G.", Color.LightGray);
            };
        }

        // ---------------------------------------------------------------- layout
        void BuildMenu()
        {
            MenuStrip m = new MenuStrip();
            ToolStripMenuItem file = new ToolStripMenuItem("&File");
            file.DropDownItems.Add("&Install Mac OS X...", null, delegate { DoInstall(); });
            file.DropDownItems.Add("Import disk &image...", null, delegate { DoImport(false); });
            file.DropDownItems.Add("Import &UTM bundle...", null, delegate { DoImport(true); });
            file.DropDownItems.Add(new ToolStripSeparator());
            file.DropDownItems.Add("Open &VM folder", null, delegate { OpenFolder(Env.VmDir); });
            file.DropDownItems.Add(new ToolStripSeparator());
            file.DropDownItems.Add("E&xit", null, delegate { Close(); });
            ToolStripMenuItem vm = new ToolStripMenuItem("&Machine");
            vm.DropDownItems.Add("&Start", null, delegate { DoStart(); });
            vm.DropDownItems.Add("S&top (force)", null, delegate { DoStop(); });
            vm.DropDownItems.Add(new ToolStripSeparator());
            vm.DropDownItems.Add("&Delete this VM...", null, delegate { DoDelete(); });
            ToolStripMenuItem tools = new ToolStripMenuItem("&Tools");
            tools.DropDownItems.Add("&Check setup", null, delegate { DoCheck(); });
            tools.DropDownItems.Add("&Build / Update QEMU", null, delegate { DoBuild(); });
            tools.DropDownItems.Add("Open build &log", null, delegate { OpenBuildLog(); });
            tools.DropDownItems.Add("Open &QEMU log (last run)", null, delegate { OpenFile(Path.Combine(Env.VmDir, "qemu.log")); });
            ToolStripMenuItem help = new ToolStripMenuItem("&Help");
            help.DropDownItems.Add("&Documentation", null, delegate { OpenFile(Path.Combine(Path.Combine(Env.Root, "docs"), "WINDOWS.md")); });
            help.DropDownItems.Add("&About", null, delegate
            {
                MessageBox.Show(this, "ppcosxkvm for Windows\r\n\r\nPowerPC Mac OS X on an emulated ATI Radeon 9700 PRO with 3D acceleration through Vulkan.\r\n\r\nThis window is a front-end for ppcosx.ps1 and QEMU.", "About");
            });
            m.Items.AddRange(new ToolStripItem[] { file, vm, tools, help });
            MainMenuStrip = m;
            Controls.Add(m);
        }

        void BuildLayout()
        {
            // ---- sidebar
            Panel side = new Panel(); side.Dock = DockStyle.Left; side.Width = 250; side.BackColor = SideBg;
            Label title = new Label(); title.Text = "PowerPC\r\nMac OS X"; title.ForeColor = Color.White; title.Font = new Font("Segoe UI Semibold", 15f);
            title.Dock = DockStyle.Top; title.Height = 76; title.Padding = new Padding(16, 14, 0, 0);
            Label sub = new Label(); sub.Text = "Radeon 9700 PRO  \u00B7  Vulkan 3D"; sub.ForeColor = Color.FromArgb(140, 148, 160);
            sub.Dock = DockStyle.Top; sub.Height = 26; sub.Padding = new Padding(17, 0, 0, 0);

            vmList.Dock = DockStyle.Fill; vmList.BorderStyle = BorderStyle.None; vmList.BackColor = SideBg;
            vmList.DrawMode = DrawMode.OwnerDrawFixed; vmList.ItemHeight = 50;
            vmList.DrawItem += DrawVmItem;
            vmList.SelectedIndexChanged += delegate { OnSelect(); };

            FlowLayoutPanel bottom = new FlowLayoutPanel(); bottom.Dock = DockStyle.Bottom; bottom.FlowDirection = FlowDirection.TopDown;
            bottom.WrapContents = false; bottom.AutoSize = true; bottom.Padding = new Padding(12, 8, 12, 12);
            Button inst = SideButton("+  Install Mac OS X...", true);
            inst.Click += delegate { DoInstall(); };
            Button imp = SideButton("Import existing disk...", false);
            imp.Click += delegate { DoImport(false); };
            checkBtn = SideButton("Check setup", false);
            checkBtn.Click += delegate { DoCheck(); };
            buildBtn = SideButton("Build / Update QEMU", false);
            buildBtn.Click += delegate { DoBuild(); };
            bottom.Controls.AddRange(new Control[] { inst, imp, checkBtn, buildBtn });

            side.Controls.Add(vmList);
            side.Controls.Add(bottom);
            side.Controls.Add(sub);
            side.Controls.Add(title);

            // ---- header
            header.Dock = DockStyle.Top; header.Height = 78; header.BackColor = Color.White;
            vmTitle.Font = new Font("Segoe UI Semibold", 16f); vmTitle.AutoSize = true; vmTitle.Location = new Point(20, 12);
            status.AutoSize = true; status.Location = new Point(22, 48); status.ForeColor = Color.Gray;
            startBtn.Text = "\u25B6  Start"; StyleBig(startBtn, Accent);
            stopBtn.Text = "\u25A0  Force stop"; StyleBig(stopBtn, Danger);
            FlowLayoutPanel hb = new FlowLayoutPanel(); hb.Dock = DockStyle.Right; hb.Width = 330; hb.Padding = new Padding(0, 18, 16, 0);
            hb.FlowDirection = FlowDirection.RightToLeft; hb.Controls.Add(startBtn); hb.Controls.Add(stopBtn);
            startBtn.Click += delegate { DoStart(); };
            stopBtn.Click += delegate { DoStop(); };
            header.Controls.Add(hb); header.Controls.Add(vmTitle); header.Controls.Add(status);

            banner.Dock = DockStyle.Top; banner.Height = 30; banner.BackColor = Color.FromArgb(255, 244, 214); banner.ForeColor = Color.FromArgb(120, 80, 0);
            banner.TextAlign = ContentAlignment.MiddleLeft; banner.Padding = new Padding(20, 0, 0, 0); banner.Visible = false;

            // ---- tabs
            tabs.Dock = DockStyle.Fill;
            tabs.TabPages.Add(BuildHardwareTab());
            tabs.TabPages.Add(BuildStorageTab());
            tabs.TabPages.Add(BuildAdvancedTab());

            // ---- log
            Panel logPanel = new Panel(); logPanel.Dock = DockStyle.Fill;
            log.Dock = DockStyle.Fill; log.ReadOnly = true; log.BackColor = LogBg; log.ForeColor = Color.LightGray; log.BorderStyle = BorderStyle.None;
            log.Font = new Font(FontFamily.GenericMonospace, 9f); log.DetectUrls = false; log.WordWrap = true;
            Panel pbar = new Panel(); pbar.Dock = DockStyle.Bottom; pbar.Height = 30; pbar.BackColor = Color.FromArgb(235, 237, 240);
            preview.ReadOnly = true; preview.Dock = DockStyle.Fill; preview.BorderStyle = BorderStyle.None; preview.BackColor = Color.FromArgb(235, 237, 240);
            preview.Font = new Font(FontFamily.GenericMonospace, 8.5f);
            Button copy = new Button(); copy.Text = "Copy command"; copy.Dock = DockStyle.Right; copy.Width = 110; copy.FlatStyle = FlatStyle.System;
            copy.Click += delegate { try { Clipboard.SetText(preview.Text); } catch (Exception) { } };
            Button clear = new Button(); clear.Text = "Clear log"; clear.Dock = DockStyle.Right; clear.Width = 80; clear.FlatStyle = FlatStyle.System;
            clear.Click += delegate { log.Clear(); };
            pbar.Controls.Add(preview); pbar.Controls.Add(clear); pbar.Controls.Add(copy);
            logPanel.Controls.Add(log); logPanel.Controls.Add(pbar);

            split.Dock = DockStyle.Fill; split.Orientation = Orientation.Horizontal; split.FixedPanel = FixedPanel.None;
            split.Panel1.Controls.Add(tabs); split.Panel2.Controls.Add(logPanel);

            // ---- welcome (no VMs yet)
            welcome.Dock = DockStyle.Fill; welcome.BackColor = Color.White; welcome.Visible = false;
            Label wt = new Label(); wt.Text = "No virtual machines yet"; wt.Font = new Font("Segoe UI Semibold", 18f); wt.AutoSize = true; wt.Location = new Point(40, 40);
            Label wb = new Label(); wb.AutoSize = true; wb.Location = new Point(42, 90); wb.ForeColor = Color.DimGray;
            wb.Text = "Install Mac OS X from a DVD image, or bring a disk you already have\r\n(.qcow2, .vmdk, .vdi, .vhd, .img or a UTM bundle).";
            Button w1 = new Button(); w1.Text = "Install Mac OS X..."; StyleBig(w1, Accent); w1.Location = new Point(42, 150); w1.Click += delegate { DoInstall(); };
            Button w2 = new Button(); w2.Text = "Import existing disk..."; StyleBig(w2, Color.FromArgb(70, 80, 100)); w2.Location = new Point(200, 150); w2.Width = 190; w2.Click += delegate { DoImport(false); };
            welcome.Controls.AddRange(new Control[] { wt, wb, w1, w2 });

            Panel right = new Panel(); right.Dock = DockStyle.Fill;
            right.Controls.Add(split);
            right.Controls.Add(welcome);
            right.Controls.Add(banner);
            right.Controls.Add(header);

            Controls.Add(right);
            Controls.Add(side);
            MainMenuStrip.SendToBack();   // menu docks above everything
            Shown += delegate { try { split.SplitterDistance = Math.Max(250, split.Height - 230); } catch (Exception) { } };
        }

        Button SideButton(string text, bool primary)
        {
            Button b = new Button(); b.Text = text; b.Width = 226; b.Height = 34; b.FlatStyle = FlatStyle.Flat; b.TextAlign = ContentAlignment.MiddleLeft;
            b.Padding = new Padding(8, 0, 0, 0); b.Margin = new Padding(0, 0, 0, 6);
            b.ForeColor = Color.White; b.BackColor = primary ? Accent : Color.FromArgb(52, 57, 68);
            b.FlatAppearance.BorderSize = 0; b.Cursor = Cursors.Hand;
            return b;
        }

        void StyleBig(Button b, Color c)
        {
            b.FlatStyle = FlatStyle.Flat; b.BackColor = c; b.ForeColor = Color.White; b.Width = 140; b.Height = 40;
            b.Font = new Font("Segoe UI Semibold", 10f); b.FlatAppearance.BorderSize = 0; b.Cursor = Cursors.Hand;
        }

        void DrawVmItem(object sender, DrawItemEventArgs e)
        {
            if (e.Index < 0) return;
            VmProfile p = (VmProfile)vmList.Items[e.Index];
            bool sel = (e.State & DrawItemState.Selected) != 0;
            using (SolidBrush bg = new SolidBrush(sel ? SideSel : SideBg)) e.Graphics.FillRectangle(bg, e.Bounds);
            if (sel) using (SolidBrush ab = new SolidBrush(Accent)) e.Graphics.FillRectangle(ab, e.Bounds.X, e.Bounds.Y, 4, e.Bounds.Height);
            using (Font f1 = new Font("Segoe UI Semibold", 10f))
            using (Font f2 = new Font("Segoe UI", 8.5f))
            using (SolidBrush w = new SolidBrush(Color.White))
            using (SolidBrush g = new SolidBrush(Color.FromArgb(140, 148, 160)))
            {
                e.Graphics.DrawString(p.Name, f1, w, e.Bounds.X + 16, e.Bounds.Y + 7);
                e.Graphics.DrawString(Subtitle(p), f2, g, e.Bounds.X + 16, e.Bounds.Y + 28);
            }
        }

        static string Subtitle(VmProfile p)
        {
            string card = p.Card == "vga" ? "VGA" : (p.Card == "9000" ? "Radeon 9000" : "Radeon 9700");
            bool ok = false;
            try { ok = !string.IsNullOrEmpty(p.Disk) && File.Exists(p.Disk); } catch (Exception) { }
            return card + "  \u00B7  " + p.Ram + " MB" + (ok ? "" : "  \u00B7  no disk");
        }

        static string Pretty(long b)
        {
            string[] u = { "B", "KB", "MB", "GB", "TB" }; double v = b; int i = 0;
            while (v >= 1024 && i < 4) { v /= 1024; i++; }
            return v.ToString(i == 0 ? "0" : "0.#") + " " + u[i];
        }

        // ------------------------------------------------------------------ tabs
        static TableLayoutPanel Table()
        {
            TableLayoutPanel t = new TableLayoutPanel(); t.Dock = DockStyle.Top; t.AutoSize = true; t.ColumnCount = 2; t.Padding = new Padding(14, 12, 14, 8);
            t.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 150));
            t.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100));
            return t;
        }

        static void Row(TableLayoutPanel t, string label, Control c)
        {
            Label l = new Label(); l.Text = label; l.AutoSize = true; l.Anchor = AnchorStyles.Left; l.Margin = new Padding(0, 8, 8, 8);
            c.Margin = new Padding(0, 4, 0, 4);
            if (c is CheckBox) ((CheckBox)c).AutoSize = true;
            if (c is TextBox || c is ComboBox || c is Panel || c is ListBox) c.Anchor = AnchorStyles.Left | AnchorStyles.Right; else c.Anchor = AnchorStyles.Left;
            int r = t.RowCount; t.RowCount = r + 1; t.RowStyles.Add(new RowStyle(SizeType.AutoSize));
            t.Controls.Add(l, 0, r); t.Controls.Add(c, 1, r);
        }

        static void Note(TableLayoutPanel t, Label hint)
        {
            hint.AutoSize = true; hint.ForeColor = Color.DimGray; hint.Margin = new Padding(0, 0, 0, 6); hint.MaximumSize = new Size(640, 0);
            int r = t.RowCount; t.RowCount = r + 1; t.RowStyles.Add(new RowStyle(SizeType.AutoSize));
            t.Controls.Add(hint, 1, r);
        }

        static Panel PathRow(TextBox tb, params Button[] buttons)
        {
            Panel p = new Panel(); p.Height = 28;
            tb.Dock = DockStyle.Fill;
            p.Controls.Add(tb);
            foreach (Button b in buttons) { b.Dock = DockStyle.Right; b.Width = 104; b.FlatStyle = FlatStyle.System; p.Controls.Add(b); }
            return p;
        }

        Button Btn(string text, EventHandler h) { Button b = new Button(); b.Text = text; b.Click += h; return b; }

        TabPage BuildHardwareTab()
        {
            TabPage pg = new TabPage("Hardware"); pg.BackColor = Color.White; pg.AutoScroll = true;
            TableLayoutPanel t = Table();
            Row(t, "Name", nameBox);
            cardBox.DropDownStyle = ComboBoxStyle.DropDownList; cardBox.Items.AddRange(CardNames);
            Row(t, "Graphics", cardBox);
            Note(t, cardHint);
            vramBox.DropDownStyle = ComboBoxStyle.DropDownList; vramBox.Items.AddRange(new object[] { "64", "128", "256" }); vramBox.Width = 90;
            Row(t, "Video memory (MB)", vramBox);
            resBox.DropDownStyle = ComboBoxStyle.DropDown;
            resBox.Items.AddRange(new object[] { "800x600", "1024x768", "1152x768", "1280x800", "1280x1024", "1440x900", "1600x1200", "1920x1080" }); resBox.Width = 140;
            Row(t, "Screen size", resBox);
            ramBox.Minimum = 256; ramBox.Maximum = 2048; ramBox.Increment = 128; ramBox.Width = 90;
            Row(t, "Memory (MB)", ramBox);
            modelBox.DropDownStyle = ComboBoxStyle.DropDown; modelBox.Width = 200;
            modelBox.Items.AddRange(new object[] { "PowerBook5,8", "PowerBook5,9", "PowerBook6,8", "iBook4,1", "PowerMac7,3", "default" });
            Row(t, "Mac model", modelBox);
            mhzBox.Minimum = 100; mhzBox.Maximum = 4000; mhzBox.Increment = 100; mhzBox.Width = 90;
            Row(t, "CPU speed (MHz)", mhzBox);
            Label mh = new Label(); mh.Text = "Only what Mac OS X reports; it does not make the emulation faster or slower."; Note(t, mh);
            vkBox.DropDownStyle = ComboBoxStyle.DropDownList; vkBox.Items.Add("Automatic (prefers a discrete GPU)"); vkBox.Width = 420;
            Row(t, "Host GPU (Vulkan)", vkBox);
            vkHint.Text = "Looking for GPUs..."; Note(t, vkHint);
            dispBox.DropDownStyle = ComboBoxStyle.DropDownList; dispBox.Items.AddRange(new object[] { "auto", "sdl", "gtk" }); dispBox.Width = 90;
            Row(t, "Window type", dispBox);
            soundBox.Text = "Enable sound";
            Row(t, "", soundBox);
            pg.Controls.Add(t);
            Hook(nameBox); Hook(cardBox); Hook(vramBox); Hook(resBox); Hook(ramBox); Hook(modelBox); Hook(mhzBox); Hook(vkBox); Hook(dispBox); Hook(soundBox);
            return pg;
        }

        TabPage BuildStorageTab()
        {
            TabPage pg = new TabPage("Storage"); pg.BackColor = Color.White; pg.AutoScroll = true;
            TableLayoutPanel t = Table();
            Button db = Btn("Browse...", delegate { PickFile(diskBox, "Disk images (*.qcow2;*.img;*.vmdk;*.vdi;*.vhd)|*.qcow2;*.img;*.vmdk;*.vdi;*.vhd|All files (*.*)|*.*"); });
            Button dn = Btn("Create new...", delegate { DoNewDisk(); });
            Row(t, "Disk image", PathRow(diskBox, dn, db));
            diskInfo.AutoSize = true; Note(t, diskInfo);
            Button vb = Btn("Browse...", delegate { PickFile(dvdBox, "DVD images (*.iso;*.cdr;*.dmg;*.toast)|*.iso;*.cdr;*.dmg;*.toast|All files (*.*)|*.*"); });
            Button vc = Btn("Eject", delegate { dvdBox.Text = ""; });
            Row(t, "Disc in drive", PathRow(dvdBox, vc, vb));
            Button rb = Btn("Browse...", delegate { PickFile(romBox, "Radeon ROM (*.rom;*.bin)|*.rom;*.bin|All files (*.*)|*.*"); });
            Row(t, "Radeon ROM", PathRow(romBox, rb));
            Label rh = new Label(); rh.Text = "Optional. Leave empty to use vm\\roms\\radeon9700.rom if you installed one."; Note(t, rh);
            noRomBox.Text = "Boot without a ROM even if one is installed";
            Row(t, "", noRomBox);
            snapModeBox.Text = "Throw away all changes when the VM quits (snapshot mode)";
            Row(t, "", snapModeBox);

            snapList.Height = 90; snapList.Font = new Font(FontFamily.GenericMonospace, 8.5f);
            Row(t, "Disk snapshots", snapList);
            FlowLayoutPanel sb = new FlowLayoutPanel(); sb.AutoSize = true; sb.FlowDirection = FlowDirection.LeftToRight;
            sb.Controls.Add(Btn("Save...", delegate { DoSnapshot("save"); }));
            sb.Controls.Add(Btn("Restore", delegate { DoSnapshot("restore"); }));
            sb.Controls.Add(Btn("Delete", delegate { DoSnapshot("delete"); }));
            sb.Controls.Add(Btn("Refresh", delegate { RefreshSnapshots(); }));
            foreach (Control c in sb.Controls) ((Button)c).FlatStyle = FlatStyle.System;
            Row(t, "", sb);
            pg.Controls.Add(t);
            Hook(diskBox); Hook(dvdBox); Hook(romBox); Hook(noRomBox); Hook(snapModeBox);
            return pg;
        }

        TabPage BuildAdvancedTab()
        {
            TabPage pg = new TabPage("Network && advanced"); pg.BackColor = Color.White; pg.AutoScroll = true;
            TableLayoutPanel t = Table();
            verboseBox.Text = "Verbose boot (show text instead of the grey Apple)";
            Row(t, "", verboseBox);
            sshBox.Width = 90;
            Row(t, "SSH forward port", sshBox);
            Label sh = new Label(); sh.Text = "Forwards 127.0.0.1:<port> on this PC to port 22 inside Mac OS X (turn on Remote Login there). Leave empty for none."; Note(t, sh);
            monitorBox.Text = "QEMU monitor on 127.0.0.1:4444 (HMP) and :4445 (QMP)";
            Row(t, "", monitorBox);
            traceBox.Text = "Log every GPU register access to vm\\gpu-trace.log (slow; for bug reports)";
            Row(t, "", traceBox);
            Row(t, "Extra QEMU arguments", extraBox);
            pg.Controls.Add(t);
            Hook(verboseBox); Hook(sshBox); Hook(monitorBox); Hook(traceBox); Hook(extraBox);
            return pg;
        }

        // wire any input control so edits flow into the profile and the preview
        void Hook(Control c)
        {
            if (c is TextBox) ((TextBox)c).TextChanged += delegate { OnEdit(); };
            else if (c is ComboBox) { ((ComboBox)c).SelectedIndexChanged += delegate { OnEdit(); }; ((ComboBox)c).TextChanged += delegate { OnEdit(); }; }
            else if (c is NumericUpDown) ((NumericUpDown)c).ValueChanged += delegate { OnEdit(); };
            else if (c is CheckBox) ((CheckBox)c).CheckedChanged += delegate { OnEdit(); };
        }

        void PickFile(TextBox target, string filter)
        {
            using (OpenFileDialog d = new OpenFileDialog())
            {
                d.Filter = filter;
                if (d.ShowDialog(this) == DialogResult.OK) target.Text = d.FileName;
            }
        }

        // ------------------------------------------------------ profiles <-> UI
        void LoadProfiles()
        {
            profiles.Clear();
            try
            {
                if (File.Exists(Env.ProfilesFile))
                {
                    JavaScriptSerializer js = new JavaScriptSerializer();
                    VmProfile[] arr = js.Deserialize<VmProfile[]>(File.ReadAllText(Env.ProfilesFile));
                    if (arr != null) profiles.AddRange(arr);
                }
            }
            catch (Exception ex) { Log("Could not read profiles.json: " + ex.Message, Color.Salmon); }
            if (profiles.Count == 0)
            {
                string d = Path.Combine(Env.VmDir, "macosx.qcow2");   // a disk made by the command-line launcher
                if (File.Exists(d)) { VmProfile p = new VmProfile(); p.Disk = d; profiles.Add(p); }
            }
        }

        void SaveProfiles()
        {
            try
            {
                Directory.CreateDirectory(Env.VmDir);
                JavaScriptSerializer js = new JavaScriptSerializer();
                File.WriteAllText(Env.ProfilesFile, js.Serialize(profiles.ToArray()));
            }
            catch (Exception ex) { Log("Could not save profiles.json: " + ex.Message, Color.Salmon); }
        }

        void RefreshList()
        {
            int keep = vmList.SelectedIndex;
            loading = true;
            vmList.Items.Clear();
            foreach (VmProfile p in profiles) vmList.Items.Add(p);
            loading = false;
            if (profiles.Count > 0)
            {
                int i = cur != null ? profiles.IndexOf(cur) : -1;
                if (i < 0) i = keep >= 0 && keep < profiles.Count ? keep : 0;
                vmList.SelectedIndex = i;
            }
            else { cur = null; }
            welcome.Visible = profiles.Count == 0;
            split.Visible = profiles.Count > 0;
            if (cur == null) { vmTitle.Text = ""; }
            SetState();
        }

        void OnSelect()
        {
            if (loading) return;
            int i = vmList.SelectedIndex;
            cur = i >= 0 ? profiles[i] : null;
            ProfileToUi();
        }

        void ProfileToUi()
        {
            if (cur == null) return;
            loading = true;
            VmProfile p = cur;
            vmTitle.Text = p.Name;
            nameBox.Text = p.Name;
            int ci = Array.IndexOf(CardKeys, p.Card); cardBox.SelectedIndex = ci < 0 ? 0 : ci;
            cardHint.Text = CardHints[cardBox.SelectedIndex];
            vramBox.SelectedItem = p.Vram.ToString(); if (vramBox.SelectedIndex < 0) vramBox.SelectedItem = "128";
            SetCombo(resBox, p.Res);
            ramBox.Value = Math.Max(ramBox.Minimum, Math.Min(ramBox.Maximum, p.Ram));
            SetCombo(modelBox, string.IsNullOrEmpty(p.Model) ? "default" : p.Model);
            mhzBox.Value = Math.Max(mhzBox.Minimum, Math.Min(mhzBox.Maximum, p.CpuMhz));
            SelectVk(p.VkDevice);
            dispBox.SelectedItem = p.Display; if (dispBox.SelectedIndex < 0) dispBox.SelectedIndex = 0;
            soundBox.Checked = !p.NoAudio;
            diskBox.Text = p.Disk; dvdBox.Text = p.Dvd; romBox.Text = p.Rom; noRomBox.Checked = p.NoRom; snapModeBox.Checked = p.Snapshot;
            verboseBox.Checked = p.Verbose; sshBox.Text = p.SshPort; monitorBox.Checked = p.Monitor; traceBox.Checked = p.TraceGpu; extraBox.Text = p.Extra;
            loading = false;
            UpdateDerived();
            RefreshSnapshots();
        }

        // select GPU number idx (or Automatic); a number that is not in the detected list gets a placeholder entry
        void SelectVk(string idx)
        {
            int want = 0;
            if (!string.IsNullOrEmpty(idx)) { int n; if (int.TryParse(idx, out n) && n >= 0) want = n + 1; }
            while (vkBox.Items.Count <= want) vkBox.Items.Add("GPU " + (vkBox.Items.Count - 1) + " (not detected)");
            vkBox.SelectedIndex = want;
        }

        // ask Vulkan which GPUs exist (off the UI thread) and fill the list
        void DetectGpus()
        {
            ThreadPool.QueueUserWorkItem(delegate
            {
                string note;
                List<string> devs = VulkanProbe.Devices(out note);
                try
                {
                    BeginInvoke(new Action(delegate
                    {
                        bool was = loading; loading = true;
                        while (vkBox.Items.Count > 1) vkBox.Items.RemoveAt(1);
                        foreach (string d in devs) vkBox.Items.Add(d);
                        vkHint.Text = devs.Count > 0
                            ? devs.Count + (devs.Count == 1 ? " GPU found. " : " GPUs found. ") + "Automatic picks the first discrete GPU; choose one here if it picks the wrong one."
                            : note + ". Automatic will be used.";
                        if (cur != null) SelectVk(cur.VkDevice);
                        loading = was;
                        UpdateDerived();
                    }));
                }
                catch (Exception) { }
            });
        }

        static void SetCombo(ComboBox c, string text)
        {
            int i = c.FindStringExact(text);
            if (i >= 0) c.SelectedIndex = i; else { c.SelectedIndex = -1; c.Text = text; }
        }

        void UiToProfile()
        {
            if (cur == null) return;
            VmProfile p = cur;
            p.Name = nameBox.Text.Trim().Length > 0 ? nameBox.Text.Trim() : "Mac OS X";
            p.Card = CardKeys[Math.Max(0, cardBox.SelectedIndex)];
            int v; if (int.TryParse(Convert.ToString(vramBox.SelectedItem), out v)) p.Vram = v;
            if (resBox.Text.Trim().Length > 0) p.Res = resBox.Text.Trim();
            p.Ram = (int)ramBox.Value;
            if (modelBox.Text.Trim().Length > 0) p.Model = modelBox.Text.Trim();
            p.CpuMhz = (int)mhzBox.Value;
            p.VkDevice = vkBox.SelectedIndex <= 0 ? "" : (vkBox.SelectedIndex - 1).ToString();
            p.Display = Convert.ToString(dispBox.SelectedItem);
            p.NoAudio = !soundBox.Checked;
            p.Disk = diskBox.Text.Trim(); p.Dvd = dvdBox.Text.Trim(); p.Rom = romBox.Text.Trim(); p.NoRom = noRomBox.Checked; p.Snapshot = snapModeBox.Checked;
            p.Verbose = verboseBox.Checked; p.SshPort = sshBox.Text.Trim(); p.Monitor = monitorBox.Checked; p.TraceGpu = traceBox.Checked; p.Extra = extraBox.Text;
        }

        void OnEdit()
        {
            if (loading || cur == null) return;
            UiToProfile();
            UpdateDerived();
        }

        void UpdateDerived()
        {
            if (cur == null) return;
            vmTitle.Text = cur.Name;
            cardHint.Text = CardHints[Math.Max(0, cardBox.SelectedIndex)];
            bool accel = cur.Card != "vga";
            vramBox.Enabled = accel; vkBox.Enabled = cur.Card == "9700"; traceBox.Enabled = accel;
            string di = "";
            try
            {
                if (cur.Disk.Length == 0) di = "No disk selected.";
                else if (File.Exists(cur.Disk)) di = "Using " + Pretty(new FileInfo(cur.Disk).Length) + " on disk.";
                else di = "This file does not exist yet.";
            }
            catch (Exception) { }
            diskInfo.Text = di;
            preview.Text = "ppcosx " + Args.Join(Args.ForRun(cur));
            int i = profiles.IndexOf(cur);
            if (i >= 0 && i < vmList.Items.Count) { loading = true; vmList.Items[i] = cur; loading = false; }
        }

        // ------------------------------------------------------------- logging
        // Lines from the running job are queued and drawn a few hundred at a time on a timer, so a
        // chatty program can never freeze the window.
        readonly Queue<string> pendingLines = new Queue<string>();
        System.Windows.Forms.Timer logTimer;
        int lastPct = -1;
        static readonly Regex Progress = new Regex(@"^\s*\((\d+(?:\.\d+)?)/100%\)");

        void AppendLog(string text, Color c)
        {
            if (log.TextLength > 500000) { log.Select(0, 150000); log.SelectedText = ""; }
            log.SelectionStart = log.TextLength; log.SelectionLength = 0; log.SelectionColor = c;
            log.AppendText(text + "\n");
        }

        public void Log(string text, Color c)
        {
            if (InvokeRequired) { BeginInvoke(new Action(delegate { Log(text, c); })); return; }
            AppendLog(text, c);
            log.SelectionStart = log.TextLength; log.ScrollToCaret();
        }

        void FlushLog(int max)
        {
            List<string> batch = new List<string>();
            int skipped = 0;
            lock (pendingLines)
            {
                if (pendingLines.Count > 2500) { skipped = pendingLines.Count - 2000; for (int i = 0; i < skipped; i++) pendingLines.Dequeue(); }
                while (pendingLines.Count > 0 && batch.Count < max) batch.Add(pendingLines.Dequeue());
            }
            if (batch.Count == 0 && skipped == 0) return;
            if (skipped > 0) AppendLog("(... " + skipped + " lines skipped to keep the window responsive; the full text is in the log files ...)", Color.FromArgb(150, 156, 168));
            foreach (string l in batch) LogLine(l);
            log.SelectionStart = log.TextLength; log.ScrollToCaret();
        }

        void LogLine(string line)
        {
            Match m = Progress.Match(line);
            if (m.Success)
            {
                int pct = (int)double.Parse(m.Groups[1].Value, System.Globalization.CultureInfo.InvariantCulture);
                if (pct / 10 == lastPct / 10 && pct != 100) return;
                lastPct = pct;
            }
            Color c = Color.Gainsboro;
            if (line.StartsWith("  OK ")) c = Color.FromArgb(110, 214, 130);
            else if (line.StartsWith("  !! ")) c = Color.FromArgb(240, 200, 90);
            else if (line.StartsWith("  XX ") || line.StartsWith("error:")) c = Color.FromArgb(240, 110, 110);
            else if (line.StartsWith("==>")) c = Color.FromArgb(110, 190, 240);
            else if (line.StartsWith("     ")) c = Color.FromArgb(150, 156, 168);
            AppendLog(line, c);
        }

        // ---------------------------------------------------------------- state
        bool Busy { get { return job != null && job.Running; } }

        void SetState()
        {
            if (InvokeRequired) { BeginInvoke(new Action(SetState)); return; }
            bool built = Env.QemuBuilt;
            bool have = cur != null;
            startBtn.Enabled = have && built && !Busy;
            startBtn.BackColor = startBtn.Enabled ? Accent : Color.FromArgb(160, 165, 172);
            header.Visible = have || Busy;
            stopBtn.Visible = Busy;
            startBtn.Visible = !Busy;
            checkBtn.Enabled = !Busy; buildBtn.Enabled = !Busy;
            tabs.Enabled = !Busy;
            vmList.Enabled = !Busy;
            banner.Visible = !built;
            banner.Text = "QEMU is not built yet. Use \"Build / Update QEMU\" in the sidebar to create qemu-system-ppc.exe.";
            if (Busy) { status.Text = jobTitle; status.ForeColor = Accent; }
            else if (!built) { status.Text = "Not ready: QEMU is not built"; status.ForeColor = Color.DarkOrange; }
            else if (have) { status.Text = "Ready"; status.ForeColor = Color.Gray; }
            else status.Text = "";
        }

        void Run(string title, string script, IList<string> args, Action<int> done)
        {
            if (Busy) { MessageBox.Show(this, "Something is already running.", Text); return; }
            lastPct = -1;
            Log("", Color.Gray);
            Log("> " + title, Color.FromArgb(110, 190, 240));
            jobTitle = title;
            job = new Job();
            job.OnLine = delegate(string l) { lock (pendingLines) { pendingLines.Enqueue(l); } };
            job.OnExit = delegate(int code)
            {
                BeginInvoke(new Action(delegate
                {
                    FlushLog(2500);
                    Log(code == 0 ? "Finished." : "Exited with code " + code + ".", code == 0 ? Color.FromArgb(110, 214, 130) : Color.FromArgb(240, 200, 90));
                    SetState();
                    RefreshList();
                    if (done != null) done(code);
                }));
            };
            try { job.Start(script, args); }
            catch (Exception ex)
            {
                Log("Could not start " + Env.PowerShell + ": " + ex.Message, Color.Salmon);
                job = null;
            }
            SetState();
        }

        // -------------------------------------------------------------- actions
        void DoStart()
        {
            if (cur == null) return;
            UiToProfile(); SaveProfiles();
            if (!Env.QemuBuilt) { MessageBox.Show(this, "QEMU is not built yet. Use \"Build / Update QEMU\" first.", Text); return; }
            if (cur.Card != "vga" && !Regex.IsMatch(cur.Res, @"^\d+x\d+$")) { MessageBox.Show(this, "Screen size must look like 1024x768.", Text); return; }
            if (!Regex.IsMatch(cur.Res, @"^\d+x\d+$")) { MessageBox.Show(this, "Screen size must look like 1024x768.", Text); return; }
            if (string.IsNullOrEmpty(cur.Disk) || !File.Exists(cur.Disk))
            {
                MessageBox.Show(this, "This VM has no disk yet.\r\n\r\nUse \"Create new...\" or \"Browse...\" on the Storage tab, or File > Install Mac OS X.", Text);
                tabs.SelectedIndex = 1; return;
            }
            Run("Running " + cur.Name, "ppcosx.ps1", Args.ForRun(cur), null);
        }

        void DoStop()
        {
            if (!Busy) return;
            if (MessageBox.Show(this, "Force-stop the running task?\r\n\r\nAnything unsaved inside Mac OS X is lost. (Shutting Mac OS X down normally, or closing the QEMU window, is gentler.)",
                "Force stop", MessageBoxButtons.YesNo, MessageBoxIcon.Warning) == DialogResult.Yes) job.Kill();
        }

        void DoCheck() { Run("Checking setup", "ppcosx.ps1", new string[] { "doctor" }, null); }

        void DoBuild()
        {
            if (MessageBox.Show(this, "Build qemu-system-ppc.exe now?\r\n\r\nThis installs MSYS2 (if needed) and compiles QEMU. The first time takes 20-40 minutes and needs about 8 GB of disk space and an internet connection.",
                "Build QEMU", MessageBoxButtons.OKCancel, MessageBoxIcon.Question) != DialogResult.OK) return;
            Run("Building QEMU", "build-windows.ps1", new string[] { "-NoGui", "-NoPause" }, delegate(int code)
            {
                if (code == 0) MessageBox.Show(this, "QEMU is built. You can start your VM now.", "Build finished");
                else if (MessageBox.Show(this, "The build failed.\r\n\r\nThe reason is near the end of the log pane. Everything is also saved in build-windows.log.\r\n\r\nOpen that log file now?",
                    "Build failed", MessageBoxButtons.YesNo, MessageBoxIcon.Error) == DialogResult.Yes) OpenBuildLog();
            });
        }

        string UniqueDisk(string name)
        {
            string stem = Regex.Replace(name, @"[^A-Za-z0-9._-]+", "-").Trim('-');
            if (stem.Length == 0) stem = "macosx";
            string path = Path.Combine(Env.VmDir, stem + ".qcow2");
            for (int i = 2; File.Exists(path) || profiles.Exists(delegate(VmProfile p) { return string.Equals(p.Disk, path, StringComparison.OrdinalIgnoreCase); }); i++)
                path = Path.Combine(Env.VmDir, stem + "-" + i + ".qcow2");
            return path;
        }

        void DoInstall()
        {
            if (!Env.QemuBuilt) { MessageBox.Show(this, "Build QEMU first (sidebar: Build / Update QEMU).", Text); return; }
            using (InstallDialog d = new InstallDialog())
            {
                if (d.ShowDialog(this) != DialogResult.OK) return;
                VmProfile p = new VmProfile();
                p.Name = d.VmName.Text.Trim(); p.Ram = (int)d.Ram.Value; p.Disk = UniqueDisk(p.Name);
                profiles.Add(p); cur = p; SaveProfiles(); RefreshList();
                List<string> a = new List<string>(new string[] { "install", d.Iso.Text, "--disk", p.Disk, "--size", ((int)d.SizeGb.Value) + "G", "--ram", p.Ram.ToString() });
                Run("Installing Mac OS X onto " + p.Name, "ppcosx.ps1", a, delegate(int code)
                {
                    if (code == 0) MessageBox.Show(this, "The installer has closed.\r\n\r\nIf the install finished, select the VM and press Start.", "Installer finished");
                });
            }
        }

        void DoImport(bool bundle)
        {
            if (!Env.QemuBuilt) { MessageBox.Show(this, "Build QEMU first (sidebar: Build / Update QEMU).", Text); return; }
            string src = null;
            if (bundle)
            {
                using (FolderBrowserDialog f = new FolderBrowserDialog())
                {
                    f.Description = "Choose the .utm bundle (a folder with a Data subfolder).";
                    if (f.ShowDialog(this) != DialogResult.OK) return;
                    src = f.SelectedPath;
                }
            }
            else
            {
                using (OpenFileDialog f = new OpenFileDialog())
                {
                    f.Filter = "Disk images (*.qcow2;*.vmdk;*.vdi;*.vhd;*.vhdx;*.img)|*.qcow2;*.vmdk;*.vdi;*.vhd;*.vhdx;*.img|All files (*.*)|*.*";
                    if (f.ShowDialog(this) != DialogResult.OK) return;
                    src = f.FileName;
                }
            }
            string name = Dialogs.Ask(this, "Import disk", "Name for the new virtual machine:", Path.GetFileNameWithoutExtension(src.TrimEnd('\\', '/')));
            if (string.IsNullOrEmpty(name)) return;
            VmProfile p = new VmProfile(); p.Name = name; p.Disk = UniqueDisk(name);
            List<string> a = new List<string>(new string[] { "import", src, "--as", p.Disk });
            Run("Importing " + Path.GetFileName(src.TrimEnd('\\', '/')), "ppcosx.ps1", a, delegate(int code)
            {
                if (code == 0 && File.Exists(p.Disk)) { profiles.Add(p); cur = p; SaveProfiles(); RefreshList(); }
            });
        }

        void DoNewDisk()
        {
            if (cur == null) return;
            if (!Env.QemuBuilt) { MessageBox.Show(this, "Build QEMU first.", Text); return; }
            string size = Dialogs.Ask(this, "New disk", "Size (for example 40G):", "40G");
            if (string.IsNullOrEmpty(size)) return;
            if (!Regex.IsMatch(size, @"^\d+[MGT]$", RegexOptions.IgnoreCase)) { MessageBox.Show(this, "Use a number followed by M, G or T, like 40G.", Text); return; }
            string path = cur.Disk.Length > 0 && !File.Exists(cur.Disk) ? cur.Disk : UniqueDisk(cur.Name);
            Run("Creating " + size + " disk", "ppcosx.ps1", new string[] { "new-disk", size, path }, delegate(int code)
            {
                if (code == 0) { diskBox.Text = path; }
            });
        }

        void DoDelete()
        {
            if (cur == null || Busy) return;
            DialogResult r = MessageBox.Show(this, "Remove \"" + cur.Name + "\" from the list?\r\n\r\nYes = also delete its disk file\r\nNo = keep the disk file\r\nCancel = do nothing",
                "Delete VM", MessageBoxButtons.YesNoCancel, MessageBoxIcon.Warning);
            if (r == DialogResult.Cancel) return;
            if (r == DialogResult.Yes) { try { if (File.Exists(cur.Disk)) File.Delete(cur.Disk); } catch (Exception ex) { Log("Could not delete the disk: " + ex.Message, Color.Salmon); } }
            profiles.Remove(cur); cur = null; SaveProfiles(); RefreshList();
        }

        // ------------------------------------------------------------ snapshots
        void RefreshSnapshots()
        {
            snapList.Items.Clear();
            if (cur == null || string.IsNullOrEmpty(cur.Disk) || !File.Exists(cur.Disk) || !Env.QemuBuilt) return;
            string disk = cur.Disk;
            ThreadPool.QueueUserWorkItem(delegate
            {
                List<string> lines = new List<string>();
                try
                {
                    ProcessStartInfo psi = new ProcessStartInfo(Env.PowerShell, Job.PsArgs("ppcosx.ps1", new string[] { "snapshot", "list", "--disk", disk }));
                    psi.UseShellExecute = false; psi.RedirectStandardOutput = true; psi.RedirectStandardError = true; psi.CreateNoWindow = true;
                    using (Process p = Process.Start(psi))
                    {
                        string o = p.StandardOutput.ReadToEnd(); p.StandardError.ReadToEnd(); p.WaitForExit();
                        foreach (string l in o.Split('\n')) { string t = l.TrimEnd('\r'); if (Regex.IsMatch(t, @"^(ID\s|\d+\s)")) lines.Add(t); }
                    }
                }
                catch (Exception) { }
                try { BeginInvoke(new Action(delegate { snapList.Items.Clear(); foreach (string l in lines) snapList.Items.Add(l); })); } catch (Exception) { }
            });
        }

        void DoSnapshot(string action)
        {
            if (cur == null || string.IsNullOrEmpty(cur.Disk)) return;
            string tag = null;
            if (action == "save")
            {
                tag = Dialogs.Ask(this, "Save snapshot", "Snapshot name (no spaces):", "clean-install");
                if (string.IsNullOrEmpty(tag)) return;
                if (Regex.IsMatch(tag, @"\s")) { MessageBox.Show(this, "No spaces in the name, please.", Text); return; }
            }
            else
            {
                Match m = snapList.SelectedItem == null ? null : Regex.Match((string)snapList.SelectedItem, @"^\d+\s+(\S+)");
                if (m == null || !m.Success) { MessageBox.Show(this, "Select a snapshot in the list first.", Text); return; }
                tag = m.Groups[1].Value;
                if (action == "restore" && MessageBox.Show(this, "Restore the disk to \"" + tag + "\"? Changes made since then are lost.", "Restore snapshot", MessageBoxButtons.OKCancel, MessageBoxIcon.Warning) != DialogResult.OK) return;
            }
            Run("Snapshot " + action + ": " + tag, "ppcosx.ps1", new string[] { "snapshot", action, tag, "--disk", cur.Disk }, delegate(int code) { RefreshSnapshots(); });
        }

        // ----------------------------------------------------------------- misc
        void OpenFolder(string path)
        {
            try { Directory.CreateDirectory(path); Process.Start(Env.IsWindows ? "explorer.exe" : "xdg-open", "\"" + path + "\""); } catch (Exception) { }
        }
        void OpenBuildLog()
        {
            string f = Path.Combine(Env.Root, "build-windows.log");
            if (File.Exists(f)) OpenFile(f);
            else MessageBox.Show(this, "There is no build log yet: the build has not been run from this folder.", Text);
        }
        void OpenFile(string path)
        {
            try { if (File.Exists(path)) Process.Start(path); else Log("Not found: " + path, Color.Salmon); } catch (Exception) { }
        }

        protected override void OnFormClosing(FormClosingEventArgs e)
        {
            if (Busy)
            {
                if (MessageBox.Show(this, "A task is still running. Stop it and close?", "Close", MessageBoxButtons.YesNo, MessageBoxIcon.Warning) != DialogResult.Yes) { e.Cancel = true; return; }
                job.Kill();
            }
            if (cur != null) UiToProfile();
            SaveProfiles();
            base.OnFormClosing(e);
        }
    }

    static class Program
    {
        [DllImport("user32.dll")] static extern bool SetProcessDPIAware();

        [STAThread]
        static int Main(string[] argv)
        {
            try { SetProcessDPIAware(); } catch (Exception) { }
            if (argv.Length > 0 && argv[0] == "--list-gpus")
            {
                Env.Init();
                string note; List<string> d = VulkanProbe.Devices(out note);
                try
                {
                    foreach (string g in d) Console.WriteLine(g);
                    if (d.Count == 0) Console.WriteLine(note);
                }
                catch (Exception) { }
                return 0;
            }
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            if (!Env.Init())
            {
                MessageBox.Show("Could not find ppcosx.ps1. Keep ppcosx-gui.exe in the ppcosxkvm folder.", "PowerPC Mac OS X", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return 1;
            }
            Application.Run(new MainForm());
            return 0;
        }
    }
}
