@echo off
rem Lets you type "ppcosx run" in cmd.exe or PowerShell without fiddling with execution policy.
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0ppcosx.ps1" %*
exit /b %ERRORLEVEL%
